import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.TreeSet;

//Collection is an interface
//Collections is an class having so many methods which can implement on collection
//Both are present in java.util.pacakge

public class Collection_Vs_Collections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet t = new TreeSet();
	     t.add(100);
	     t.add(50);
	     t.add(150);
		 t.add(25);
		 t.add(75);
		 t.add(125);
		 t.add(175);
		 
		 System.out.println(t);
		 
		 //collections 
		 ArrayList ar = new ArrayList();
	     ar.add(100);
	     ar.add(50);
	     ar.add(150);
		 ar.add(25);
		 ar.add(75);
		 ar.add(125);
		 ar.add(175);
		 
		 System.out.println(ar);
		 
		 Collections.sort(ar);
		 
		 System.out.println(ar);
		 
	     //Generic
		 
		 ArrayList <String> al2 = new ArrayList();
		// al2.add(28); we can't add any other type of data except string
		 al2.add("Yashu");
		 al2.add("Sanyam Singh");
		 al2.add("Thakur");
		// al2.add(2656582);
		 
		 Collections.sort(al2);
		 System.out.println(al2);
		
	   LinkedList <Integer> ll = new LinkedList();
		//ll.add("Java"); //only integer value accepted
		ll.add(27);
		ll.add(025);
		ll.add(007);
		
		Collections.sort(ll);
		System.out.println(ll);
		 
		 
		 //few imp more collections methods
		
		 ArrayList  al3 = new ArrayList();
			 al3.add(28);
			 al3.add(10);
			 al3.add(20);
			 al3.add(30);
			 al3.add(40);
			 
			 int index = Collections.binarySearch(al3, 40); //
		     System.out.println("index "+ index);
		     
		     Collections.shuffle(al3);
		     System.out.println(al3);
		     
		     System.out.println(Collections.frequency(al3, 30));
		     
		

	}

}
