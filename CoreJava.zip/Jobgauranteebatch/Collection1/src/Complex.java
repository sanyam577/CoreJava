import java.util.ArrayList;

class Students{
	private int age;
	private String name;
	private int marks;
	
	public Students(int age, String name, int marks) { 
		this.age = age;
		this.name = name;
		this.marks = marks;
	}

	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	public int getMarks() {
		return marks;
	}
	
	
}
public class Complex {

	public static void main(String[] args) {
		Students s1 = new Students(25, "Rahul", 45);
		Students s2 = new Students(21, "Mani", 65);
		Students s3 = new Students(22, "Ram", 75);
	
		/*
		ArrayList al = new ArrayList();
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(100);// we can add any value along with object class values (Students) but.... 
		*/
		
		ArrayList <Students> al = new ArrayList();
		al.add(s1);
		al.add(s2);
		al.add(s3);
	//	al.add(100); // it will throw error because this array list will accept value of Students type or values from students classonly
		System.out.println(al);
		
		
		//we can't sort using collections.sort method because object having complex data
		//here comes the concept of comparable and comparator
		
		
		
		
		
		
		
		
		

	}

}
