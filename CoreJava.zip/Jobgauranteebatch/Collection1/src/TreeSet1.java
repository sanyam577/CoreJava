import java.util.*;
public class TreeSet1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet t = new TreeSet(); //It uses binary search tree algorithm
		t.add(35);
		t.add(26);
		t.add(92);
		t.add(105);
		t.add(27);
		t.add(37);
		t.add(21);
		t.add(20);
		System.out.println(t); //result will be in ascending order
		
		System.out.println(t.ceiling(37)); //if it is present it will return the same value
		System.out.println(t.higher(37)); //nearest higher value
		System.out.println(t.floor(37));//if it is present it will return the same value
		System.out.println(t.lower(37)); //nearest lower value
		
		System.out.println("**************");
		
		System.out.println(t.ceiling(36));// same value not present then it will return nearest larger value
		System.out.println(t.higher(36));
		System.out.println(t.floor(36)); //same value not present then it will return nearest smaller value
		System.out.println(t.lower(36));
		
	}

} 




