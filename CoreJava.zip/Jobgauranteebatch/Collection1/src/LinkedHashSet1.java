import java.util.LinkedHashSet;

public class LinkedHashSet1 {
	public static void main(String [] args) {
		
		LinkedHashSet lhs = new LinkedHashSet();
		lhs.add(100);
		lhs.add(50);
		lhs.add(150);
		lhs.add(25);
		lhs.add(125);
		
		System.out.println(lhs); //it also uses hash map data structure
		                       //result will be in order of insertion
		lhs.add(25);
		System.out.println(lhs); //Duplicates are not allowed
		
	}

}
