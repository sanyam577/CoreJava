import java.util.ArrayDeque;
public class ArrayDeque3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          ArrayDeque AD1 = new ArrayDeque();
          
         AD1.add(10);
         AD1.add(20);
	     AD1.add(90);
	     System.out.println(AD1);
	     //All method of arraylist is valid
	}

}
