import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.TreeSet;

public class CollectionImportantPoints {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       ArrayList al = new ArrayList();
       //auto boxing is done because collection is an object and here we are passing data as primitive type
        al.add(10);  //al.add(new Interger(10));
        al.add(10.5);  //al.add(new Double(10.5));
        al.add('c');    //al.add(new Character('c'));
        al.add(10.0f);   
        
      //System.out.println(al);
        
        ArrayList al2 = new ArrayList();
        al2.add(10);
        al2.add(20);
        al2.add(30);
        al2.add(40);
        al2.add(50);
       // System.out.println(al2);
        
        //Different ways to access data present within collection
        //1. Normal Loop
        
        /*
        //for loop
        System.out.println(al2.size());
        for(int i=0; i<al2.size(); i++) {
        //	Object o = al2.get(i);
        //	System.out.println(o);
        	System.out.println(al2.get(i));
        }
        
        //for each 
        for(Object obj:al2) {
        	System.out.println(obj);
        }
        */
        
        //2. Iterator 
        Iterator itr1 =al2.iterator();
        
      //  if(itr1.hasNext()) {
        //	System.out.println(itr1.next());
        //}
        
        while(itr1.hasNext()) { //it will take the cursor at first point
      // Integer i=(Integer)itr1.next(); //it will go and fetch the value //explicit type casting because itr1 is an object
       // Object o = itr1.next();           //and we are trying to save it in Child class which is Integer here        
        System.out.println(itr1.next());
        }
        
        
        System.out.println("reverse");
        
        ListIterator lt = al2.listIterator(al2.size()); //it is used to reverse collection of arraylist and linkedlist type
        while(lt.hasPrevious()) {
        	System.out.println(lt.previous());
        }
        
        System.out.println("**************");
        //we can' use listiterator to reverse other collection type
        //so we are going to do this to reverse any type of collection
        
        TreeSet ts = new TreeSet();
         ts.add(10);
         ts.add(20);
         ts.add(30);
         ts.add(40);
         Iterator it = ts.iterator();
         
         while(it.hasNext()) {
        	 System.out.println(it.next());
         }
         System.out.println("reverse of TreeSet");
        LinkedList ll = new LinkedList();
        ll.addAll(ts); //it will copy all element of treeset to linkedlist
        
        ListIterator aa=ll.listIterator(ll.size());
        
        while(aa.hasPrevious()) {
        	System.out.println(aa.previous());
        }
        
        //descending iterator is vaild for LinkedList, TreeSet and ArrayDeque
        TreeSet ts1 = new TreeSet();
        ts1.add(100);
        ts1.add(200);
        ts1.add(300);
        ts1.add(400);
        Iterator it1 = ts1.descendingIterator();
        
        while(it1.hasNext()) {
        	System.out.println(it1.next());
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
	}

}
