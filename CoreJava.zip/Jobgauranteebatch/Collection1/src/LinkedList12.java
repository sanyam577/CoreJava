import java.util.LinkedList;

public class LinkedList12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList lL1 = new LinkedList();
		lL1.add(25);
		lL1.add("raju");
		lL1.add(50);
		lL1.add(75.5);
		lL1.add('y');
		
		System.out.println(lL1);
		
	//	lL1.add(0,28);
	//	System.out.println(lL1);
		LinkedList L2 = new LinkedList();
		
		L2.add(10);
		L2.add(20);
		
		//lL1.addAll(L2);
		//System.out.println(lL1);
		
		lL1.addFirst(36);
		lL1.addLast(36); //we can add duplicates
		System.out.println(lL1);
		
		//System.out.println(lL1.equals(L2));
		
		//System.out.println(lL1.containsAll(lL1));
		
		System.out.println(L2.get(0));
		System.out.println(L2.get(0));
		System.out.println(L2.getFirst());
		System.out.println(L2.getLast());
		//System.out.println(L2.hashCode());
		System.out.println(L2.isEmpty());
		L2.offerFirst(5);
		L2.offerLast(55);
		System.out.println(L2);
		System.out.println(L2.indexOf(20));
		
		System.out.println(L2);
		System.out.println(L2.peekFirst());
		System.out.println(L2);
		System.out.println(L2.pollFirst()); //Retrieve and remove first element
		System.out.println(L2);
		
		lL1.clear();
		System.out.println(lL1);
		System.out.println(lL1.size());
		
		
	}

}
