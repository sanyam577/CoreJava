import java.util.*;
public class PriorityQueue1 {

	public static void main(String[] args) {
		
		PriorityQueue pq = new PriorityQueue(); //it follows min-heap data structure
		pq.add(35);
		pq.add(26);
		pq.add(92);
		pq.add(105);
		pq.add(27);
		pq.add(37);
		pq.add(21);
		pq.add(20);
		System.out.println(pq);
		pq.add(37);
	    System.out.println(pq); //we can add duplicates and it will be added in the last

	}

}
