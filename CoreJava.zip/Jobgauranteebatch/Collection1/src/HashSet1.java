import java.util.*;

public class HashSet1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet h = new HashSet();
		h.add(100);
		h.add(50);
		h.add(150);
		h.add(25);
		h.add(125);
		System.out.println(h); //it uses hashmap data structure
		                         //result is not in order of insertion

	}

}
