import java.util.Enumeration;
import java.util.Vector;

public class Enumerator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		Vector v = new Vector();
		v.add(20);
		v.add(30);
		v.add(35);
		v.add(40);
		
	   Enumeration	 e=v.elements();
	   
	   while(e.hasMoreElements()) {
		   System.out.println(e.nextElement());
	   }	
	}

}
