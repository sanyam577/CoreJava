import java.util.*;

public class ArrayList1 {

	public static void main(String[] args) {
		ArrayList al1 = new ArrayList();
		al1.add(10);
		al1.add('y');
		al1.add("Yashu");
		al1.add(20);
		al1.add(8.5);
		//homogeneous type and heterogeneous type of data is allowed
		System.out.println(al1);
		System.out.println("*****************");
		 
		ArrayList al2 = new ArrayList();
		al2.add(10);
		al2.add(20);
		al2.add(30);
		al2.add(40);
		System.out.println(al2);
		System.out.println("*****************");
		
		//we can add entire collection into another collection
		ArrayList al3 = new ArrayList();
		al3.addAll(al1);
		System.out.println(al3);
		
        ArrayList al4 = new ArrayList();
        al4.add(11);
        al4.add(22);
        al4.add(33);
        al4.add(55);
		
        System.out.println("existing data "+al4);
        
        //al4.add(2, 28);
        
        //System.out.println("after adding in 2nd index "+ al4);
        
        al4.add(0, 27);
        System.out.println("after adding in 0nd index "+ al4);
        
        al4.add(55);
        System.out.println("after adding at last postion by default"+ al4);
        
        al4.add(1, al1);
        System.out.println("after adding in 2nd index "+ al4);
        
        
        
	}

}





