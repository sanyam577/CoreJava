import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class FailFastFailSafe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList t = new ArrayList();
		
		t.add(10);
		t.add(20);
		t.add(30);
		t.add(40);
		t.add(50);
		
		/*
		for(int i=0; i<t.size(); i++) {
			System.out.println(t.get(i)); // if we add value while accessing, the program will run forever
			t.add(10);   //this will throw error 
		}
		*/
		
		//fail fast
		Iterator itr = t.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
	//		t.add(60);    // if we add while assessing it will result in ConcurrentModificationException
		}                   //program will fail abruptly 
		
		//FailSafe
		CopyOnWriteArrayList cwa = new CopyOnWriteArrayList(); //this class is present in concurrent package
		
		cwa.add(1000);
		cwa.add(2000);
		cwa.add(3000);
		cwa.add(4000);
		
		Iterator it = cwa.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
			cwa.add(5000); //it will fail to add but our program is safe
		}
		
		
		/*
        CopyOnWriteArrayDeque cw = new CopyOnWriteArrayDeque(); 
		
		cwa.add(1000);
		cwa.add(2000);
		cwa.add(3000);
		cwa.add(4000);
		
		Iterator it = cwa.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
			cwa.add(5000); //it will fail to add but our program is safe
		}
		
		*/
		
	}

}
