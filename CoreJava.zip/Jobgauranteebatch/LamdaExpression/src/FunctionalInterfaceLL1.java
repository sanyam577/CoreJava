//when a interface have only only one method in it then it is vaild for lambda expression and this kind of interface is known as functional interface

@FunctionalInterface
interface Demo{
	void disp();
}
public class FunctionalInterfaceLL1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		{
			
			Demo d = () ->
			{
				System.out.println("hello rockstars");
			};
			
		    d.disp();
		    
		   /* Demo d = () -> System.out.println("hello rockstars");

			
		    d.disp();
              */
	}
	
}	
}

