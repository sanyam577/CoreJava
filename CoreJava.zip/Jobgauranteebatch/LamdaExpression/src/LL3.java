// Simple lambda
/*
@FunctionalInterface
interface Add{
	void add();
}


public class LL3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Add a = ()->{
			int num1 = 10;
			int num2 = 20;
			int res = num1 + num2;
			System.out.println(res);
		};
		a.add();
		
	}

}
*/
/*
@FunctionalInterface
interface Add{
	void add(int a, int b);
}

public class LL3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Add ad = (a ,b)->{
			
			int res = a + b;
			System.out.println(res);
		};
		ad.add(10, 20);
		
	}

}*/
/*
@FunctionalInterface
interface Add{
	void add(int a, int b);
}

public class LL3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Add ad = (int a ,int b)->{ //we can write int also
			
			int res = a + b;
			System.out.println(res);
		};
		ad.add(10, 20);
		
	}

}*/

/*
@FunctionalInterface
interface Add{
	void add(int a, int b);
}

public class LL3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Add ad = (a ,b)->{
			
			int res = a + b;
			System.out.println(res);
		};
		ad.add(10, 20);
		
	}

} */

@FunctionalInterface
interface Sub{
	int sub(int a, int b);
}

public class LL3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sub sb = (a, b) -> {
			int res = b-a;
			return res;
		};
		
		System.out.println(sb.sub(10, 20));
	}

}

















/*
@FunctionalInterface
interface Sub{
	int sub(int a);
}

public class LL3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sub sb = a -> a-5;
			System.out.println(sb.sub(10));		
	}

}*/




