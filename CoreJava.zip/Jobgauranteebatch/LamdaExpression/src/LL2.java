/*Old way
 * 
@FunctionalInterface
interface Demo1{
	void disp();
}

class Display implements Demo1{
	public void disp() {
		System.out.println("Hii Sri");
	}
}

public class LL2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display d = new Display();
		d.disp();
		
	}

}*/
 // new way 


/*
@FunctionalInterface
interface Demo1{
	void disp();
}

public class LL2 {

	public static void main(String[] args) {
		//Anonymous inner class 
	Demo1 d = new Demo1() {
		public void disp() {
			System.out.println("Hii SriLaxmi");
		}
	};
	d.disp();
		
		
		
	}
} */



//

/*
interface Demo1{
	void disp();
	void add(int a, int b);
}

public class LL2 {

	public static void main(String[] args) {
		//Anonymous inner class 
	Demo1 d = new Demo1() {//two inner method
		public void disp() {
			System.out.println("Hii SriLaxmi");
		}
		public void add(int a, int b) {
			int c= a+b;
			System.out.println(c);
		}
	};
	d.disp();
	d.add(10,20);	
			
	}
}
*/

interface Demo1{
	void disp();
	void add(int a, int b);
}

interface Demo2{
	void sub(int x, int y);
}

public class LL2 {

	public static void main(String[] args) {
		//Anonymous inner class 
	Demo1 d = new Demo1() {//two inner method
		public void disp() {
			System.out.println("Hii SriLaxmi");
		}
		public void add(int a, int b) {
			int c= a+b;
			System.out.println(c);
		}
	};
	
	Demo2 dd = new Demo2() {
		public void sub(int x, int y) {
			int s = x-y;
			System.out.println(s);
		}
	};
	
	d.disp();
	d.add(10,20);
	dd.sub(30, 20);
			
	}
}





