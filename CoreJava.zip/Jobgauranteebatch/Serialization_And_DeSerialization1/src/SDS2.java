//import java.io.*;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
//in this case we are going to get the userName but not password 
//Username is :: Sachin
//Username is :: null
//to get password we go for customized serialization

/*
class Account implements Serializable{
	String userName ="Sachin";
	transient String password ="tendulkar";
}
public class SDS2 {

	public static void main(String[] args)throws Exception {
		
		
		Account account = new Account();
		
		System.out.println("Serialization started");
		String fileName = "abcd.ser";
		FileOutputStream fos = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(account); //this is the method perform serialization for our object
		
        System.out.println("Serialization ended");
        
        System.in.read(); //this will make us wait on console until we don't press enter
        
        System.out.println("De-Serialization started");
		FileInputStream fis = new FileInputStream("abcd.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Account acc =(Account)ois.readObject();
		
		System.out.println("Username is :: "+acc.userName);
        System.out.println("Username is :: "+acc.password);
        
        System.out.println("De-Serialization ended");
		

	}

}
*/

//Customized Serialization 
//we do some extra thing with the help of two method 
//we have to write and read separately with the help of 

/*
class Account implements Serializable{
	String userName ="Sachin";
	transient String password ="tendulkar"; //loss of data
	
	
	//write a logic for serialization
  private void writeObject(ObjectOutputStream oos) throws Exception{
	  System.out.println("outer writeObject method is called ");
	  
	  //perform default serialization
	  oos.defaultWriteObject();
	  
	  //perform encryption on password
	  String encypwd ="123" +password;
	  
	//write the encrypted data to file(abcd.ser)
	  oos.writeObject(encypwd);
  }	
	
  
  
    //write a logic for serialization
  private void readObject(ObjectInputStream ois) throws Exception{
	  System.out.println("outer readObject method is called ");
	  
	//perform default de-serialization
	  ois.defaultReadObject();
	  
	 //read encrypted data from serialized file
	   String encypwd =(String)ois.readObject();
	   
	 //perform decryption and attach it to instance variable
	   password= encypwd.substring(3);
  }
	
		
}
public class SDS2 {

	public static void main(String[] args)throws IOException,ClassNotFoundException {
		
		
		Account account = new Account();
		
		System.out.println("Serialization started");
		String fileName = "abcd.ser";
		FileOutputStream fos = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(account); //this is the method perform serialization for our object
		
        System.out.println("Serialization ended");
        
        System.in.read(); //this will make us wait on console until we don't press enter
        
        System.out.println("De-Serialization started");
		FileInputStream fis = new FileInputStream("abcd.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Account acc =(Account)ois.readObject();
		
		System.out.println("Username is :: "+acc.userName);
        System.out.println("Username is :: "+acc.password);
        
        System.out.println("De-Serialization ended");
		

	}

}
*/


//add pin

class Account implements Serializable{
	String userName ="Sachin";
	transient String password ="tendulkar"; //loss of data
	transient int pin = 4444; //loss of data
	
	
	//write a logic for serialization
  private void writeObject(ObjectOutputStream oos) throws Exception{
	  System.out.println("outer writeObject method is called ");
	  
	  //perform default serialization
	  oos.defaultWriteObject();
	  
	  //perform encryption on password and pin
	  String encypwd ="123" +password;
	  int encypin = 1111+pin; //5555
	  
	//write the encrypted data to file(abcd.ser)
	  oos.writeObject(encypwd);
	  oos.writeInt(encypin);
  }	
	
  
  
    //write a logic for serialization
  private void readObject(ObjectInputStream ois) throws Exception{
	  System.out.println("outer readObject method is called ");
	  
	//perform default de-serialization
	  ois.defaultReadObject();
	  
	 //read encrypted data from serialized file
	   String encypwd =(String)ois.readObject();
	   int encypin = ois.readInt();
	   
	 //perform decryption and attach it to instance variable
	   password= encypwd.substring(3);
	   pin     =encypin - 1111;  //4444
  }
	
		
}
public class SDS2 {

	public static void main(String[] args)throws IOException,ClassNotFoundException {
		
		
		Account account = new Account();
		
		System.out.println("Serialization started");
		String fileName = "abcd.ser";
		FileOutputStream fos = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(account); //this is the method perform serialization for our object
		
        System.out.println("Serialization ended");
        
        System.in.read(); //this will make us wait on console until we don't press enter
        
        System.out.println("De-Serialization started");
		FileInputStream fis = new FileInputStream("abcd.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Account acc =(Account)ois.readObject();
		
		System.out.println("Username is :: "+acc.userName);
        System.out.println("Password is :: "+acc.password);
        System.out.println("Pin is :: "+acc.pin);
        System.out.println("De-Serialization ended");
		

	}

}

















