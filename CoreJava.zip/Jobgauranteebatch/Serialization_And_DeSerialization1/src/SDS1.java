import java.io.*;

//in serialized file we will get ByteCode of Dog object
//on De-Serialization of file we will get the object back 
/*
class Dog implements Serializable{
	static {
		System.out.println("static block gets executed...");
		}
	Dog(){
		System.out.println("Object is created....");
	}
	int i=10;
	int j=20;
}

public class SDS1 {

	public static void main(String[] args)throws Exception {
		
		Dog d = new Dog();
		System.out.println("Serialization started");
		String fileName = "abcd.ser";
		FileOutputStream fos = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(d); //this method 
		System.out.println("Serialization object reference is :: "+d);
        System.out.println("Serialization ended");
        
        System.in.read(); //this will make us wait on console until we don't press enter
        
        System.out.println("De-Serialization started");
		FileInputStream fis = new FileInputStream("abcd.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Object obj =ois.readObject();
		Dog d1 =(Dog)obj;
		System.out.println("De-Serialization object reference is :: "+d1);
        System.out.println("De-Serialization ended");
		
	}

}
*/


//What is readObject and writeObject?
//In serialization, the writeObject method writes the byte stream in physical location. 3. The readObject method is used to read 
//byte stream from physical location and type cast to required class. 
/*
class Dog implements Serializable{
	static {
		System.out.println("static block gets executed...");
		}
	Dog(){
		System.out.println("Dog Object is created....");
	}
	int i=10;
	int j=20;
}

class Cat implements Serializable{
	static {
		System.out.println("static block gets executed...");
		}
	Cat(){
		System.out.println("Cat Object is created....");
	}
	int i=100;
	int j=200;
}


public class SDS1 {

	public static void main(String[] args)throws Exception {
		
		Dog d = new Dog();
		Cat c = new Cat();
		System.out.println("Serialization started");
		String fileName = "abcd.ser";
		FileOutputStream fos = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(d); //this method 
		oos.writeObject(c);
        System.out.println("Serialization ended");
        
        System.in.read(); //this will make us wait on console until we don't press enter
        
        System.out.println("De-Serialization started");
		FileInputStream fis = new FileInputStream("abcd.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Dog d1 =(Dog)ois.readObject();
		Cat c1 =(Cat)ois.readObject();
		
		System.out.println("Dog object data is :: "+d1.i +"----->"+d1.j);
		System.out.println("Cat object data is :: "+c1.i +"----->"+c1.j);
        System.out.println("De-Serialization ended");
		
	}

}
*/

/*
//transient keyword is used in front of variable
//if we want a variable not to participate in serialization we use transient keyword

class Dog implements Serializable{
	static {
		System.out.println("static block gets executed...");
		}
	Dog(){
		System.out.println("Dog Object is created....");
	}
	   transient int i=10;
	   //final transient int i=10; final variable will participate in serialization directly by their value
	                              //so it is of no use to write final transient together
	   //static transient int i=10; static variable is not a part of object hence they would not participate in serialization 
	                                 //because of this declaring a static variable transient there is no use
	   int j=20;
}

public class SDS1 {

	public static void main(String[] args)throws Exception {
		
		Dog d = new Dog();
		
		System.out.println("Serialization started");
		String fileName = "abcd.ser";
		FileOutputStream fos = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(d); //this method 
		
        System.out.println("Serialization ended");
        
        System.in.read(); //this will make us wait on console until we don't press enter
        
        System.out.println("De-Serialization started");
		FileInputStream fis = new FileInputStream("abcd.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Dog d1 =(Dog)ois.readObject();
		
		
		System.out.println("Dog object data is :: "+d1.i +"----->"+d1.j);
		
        System.out.println("De-Serialization ended");
		
	}

}

*/


//if one object is serialized then you have to serialized other objects to which are linked with first one
//otherwise it will result in java.io.NotSerializableException 
//so here we have implements Serializable for cat and rat too.



class Dog implements Serializable{
	Cat c= new Cat();
}
class Cat  implements Serializable{
	Rat r = new Rat();
}
class Rat implements Serializable{
	int j =89;
}


public class SDS1 {

	public static void main(String[] args)throws Exception {
		
		Dog d = new Dog();
		
		System.out.println("Serialization started");
		String fileName = "abcd.ser";
		FileOutputStream fos = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(d); //this method 
		
        System.out.println("Serialization ended");
        
        System.in.read(); //this will make us wait on console until we don't press enter
        
        System.out.println("De-Serialization started");
		FileInputStream fis = new FileInputStream("abcd.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Dog d1 =(Dog)ois.readObject();
		
		System.out.println(d1.c.r.j);
        System.out.println("De-Serialization ended");
		
	}

}
















