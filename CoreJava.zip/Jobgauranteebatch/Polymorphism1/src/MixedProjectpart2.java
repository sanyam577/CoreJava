import java.util.Scanner;
abstract class Shapes{
	
	public float area;
	
	abstract public void input();
	abstract public void compute();
	public void display()
	{
		System.out.println("Area is "+ area);
	}	
}



class Rectangle1 extends Shapes{
	public float length;
	public float breadth;
	public void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Length");
		length = scan.nextFloat();
		System.out.println("Enter breadth");
		breadth = scan.nextFloat();
	}
	public void compute() {
		area = length*breadth;
	}
	
}



class Square1 extends Shapes{
	public float length;
	 
	
	public void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Length");
		length = scan.nextFloat();
		}
	
	public void compute() {
		area = length*length;
	}
}



class Circle1 extends Shapes{
	public float radius;
	final public float pi = 3.414f;
	
	public void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter radius");
		radius = scan.nextFloat();	
	}
	public void compute() {
		area = pi*radius*radius;
	}	
}



class Geometry {
	public void permit(Shapes  s) {
		s.input();
		s.compute();
		s.display();
	}
}

public class MixedProjectpart2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle1 rec = new Rectangle1();
		Square1 sq = new Square1();
		Circle1 cr = new Circle1();
		
		Geometry gc = new Geometry();
		gc.permit(rec);
		gc.permit(sq);
		gc.permit(cr);
		
	}

}













