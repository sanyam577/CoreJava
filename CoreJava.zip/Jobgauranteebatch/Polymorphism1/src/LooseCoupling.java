class Parent{
	public void cry() {
		
	System.out.println("This is parent and he is crying");
	
	}
}
 class Child1 extends Parent{
	 public void cry() {
			
			System.out.println("This is Child1 and he is crying");
			
			}
	 
 }
 class Child2 extends Parent{
	 public void cry() {
			
			System.out.println("This is Child2 and he is crying");
			
			}
	 
 }





public class LooseCoupling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child1 c1 = new Child1(); //here object name Child1() is same as reference name Child1 . That's why c1.cry is considered as tightly coupled
		Child2 c2 = new Child2();
		c1.cry(); 
		c2.cry();
		//Parent pp = new Child1();  here in this case reference type parent and object name is as of child, that's why it is known as loose coupling

		
		Parent ref; //this is not object this is just reference
		ref=c1;
		ref.cry();
		
		ref=c2;
		ref.cry();
	}

}
