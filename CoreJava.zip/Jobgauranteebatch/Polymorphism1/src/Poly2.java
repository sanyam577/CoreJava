class Plane{
	public void takeOff() //inherited method
	{
		System.out.println("Plane is taking off");
	}	
	public void fly() 
	{
		System.out.println("Plane is flying");
	}
	public void land() //inherited method
	{
		System.out.println("Plane is landing");
	}	
}



class CargoPlane extends Plane{
	public void fly() //overridden method (because it is already present in parent class and here we are modifying it)
	{
		System.out.println("CargoPlane flys at lower height");
	}
	public void carryGoods() //Specialized method (newly introduced not present in parent class)
	{
		System.out.println("CargoPlane carries goods");
	}
	
}

class PassengerPlane extends Plane{
	public void fly()  //overridden method
	{
		System.out.println("PassangerPlane flys at minimum height");
	}
	public void carryPassanger() //Specialized method
	{
		System.out.println("It carries passangers");
	}
	
}
class FighterPlane extends Plane{
	public void fly()  //overridden method
	{
		System.out.println("PassangerPlane flys at higher height");
	}
}

class Airport {
	public void permit(Plane plane) { //polymorphism 
		plane.takeOff();
		plane.fly();
		plane.land();
	}
}


public class Poly2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CargoPlane cp = new CargoPlane();
		PassengerPlane pp = new PassengerPlane();
		FighterPlane fp = new FighterPlane();
		
		Airport a= new Airport();
		a.permit(cp);
		a.permit(pp);
		a.permit(fp);
		
		
		
		
		
		
		
		
	//	Plane plane;
	//	plane = cp;
	
	//	plane.takeOff();
//		plane.fly();
	//	plane.land();
		
		
 //    plane = pp;
		
	//	plane.takeOff();
//		plane.fly();
	//	plane.land();
		

	}

}



