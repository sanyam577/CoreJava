

abstract class Plane1 // we have to write abstract before a class if any of the method present in it is of abstract type
{
	//abstract public int i =7; we can't use abstract for variables
	abstract public void takeOff(); // method can be abstract
	abstract public void fly();
	abstract public void landing();
	public void airport() { //we can have concrete method along with abstract method in a same class
		System.out.println("All planes needs airport");
	}
	
	
}

class CargoPlane1 extends Plane1
{

	public void fly()
	{
		System.out.println("CargoPlane flies at lower hieght");
	}
	public void takeOff()
	{
		System.out.println("Plane is taking off");
	}
	public void landing()
	{
		System.out.println("Plane is landing");
	}
	
}
class PassengerPlane1 extends Plane1
{
	public void fly()
	{
		System.out.println("PassengerPlane flies at medium height");
	}
	public void takeOff()
	{
		System.out.println("Plane is taking off");
	}
	public void landing()
	{
		System.out.println("Plane is landing");
	}
	
}
class Airport1 {
	public void permit(Plane1 plane) {
		plane.takeOff();
		plane.fly();
		plane.landing();
	}
}




public class AbstractionPlane {
	public static void main(String[] args) {
		
		CargoPlane1 cp=new CargoPlane1();
		
		PassengerPlane1 pp=new PassengerPlane1();
		 
		
		Airport1 a=new Airport1();
		a.permit(cp);
		a.permit(pp);
		
		

		 
		
	
	}

}





