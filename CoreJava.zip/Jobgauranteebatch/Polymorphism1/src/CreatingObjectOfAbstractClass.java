abstract class Loan1{
	abstract public void dispInt();
	public void welcomeNote(){
		System.out.println("You are welcome to 777 bank");
	}
	
	}

class HomeLoan extends Loan1{
	public void dispInt(){
		System.out.println("Interest Rate is 12%");
	}
}

class EducationLoan extends Loan1 {
	public void dispInt(){
		System.out.println("Interest Rate is 7%");
	}
	
}



public class CreatingObjectOfAbstractClass {

	public static void main(String[] args) {
		
		
		//Loan1 L = new Loan1();  We can not create object of abstract class
		
		
		Loan1 HL = new HomeLoan(); // but we can use refrence variable of abstract class (Loan1)
		HL.dispInt();
		HL.welcomeNote();
		
		Loan1 EL = new EducationLoan();
		EL.dispInt();
		EL.welcomeNote();
		

	}

}
