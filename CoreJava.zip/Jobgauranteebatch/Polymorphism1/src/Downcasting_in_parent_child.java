class Parents {
	public void cry() {
		System.out.println("parent cry");
	}
}

class Child11 extends Parents{
	public void cry() {
		System.out.println("Child1 cry a lot");
	}
	public void eat() { //specialized method
		System.out.println("Child1 eats a less");
	}
}

class Child22 extends Parents{
	public void cry() {
		System.out.println("Child2 cry a less");
	}
	public void eat() { //specialized method
		System.out.println("Child2 eats a more");
	}
}




public class Downcasting_in_parent_child {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Parents p1 = new Child11();
		p1.cry(); // we can directly use parent type reference for child method which is of overridden type this is known as upcasting
		//p1.eat() // here we are getting error because we can't use parent type method for specialized method of child 
		((Child11)p1).eat(); // for that we do downcasting :- this is used to called the specialized method of child
		
		Parents p2 = new Child22();
		p2.cry();
		//p2.eat() // here we are getting error because we can't use parent type method for specialized method of child
		((Child22)p2).eat();
	}

}
