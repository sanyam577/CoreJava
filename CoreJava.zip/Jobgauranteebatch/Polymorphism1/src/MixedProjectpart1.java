import java.util.Scanner;

class Rectangle{
	public float length;
	public float breadth;
	public float area;
	 
	
	public void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Length");
		length = scan.nextFloat();
		System.out.println("Enter breadth");
		breadth = scan.nextFloat();
	}
	
	public void compute() {
		area = length*breadth;
	}
	public void display()
	{
		System.out.println("Area of rectangle is "+ area);
	}	
}



class Square {
	public float length;
	public float area;
	 
	
	public void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Length");
		length = scan.nextFloat();
		
	}
	
	public void compute() {
		area = length*length;
	}
	public void display()
	{
		System.out.println("Area of square is "+ area);
	}	
	
}

class Circle{
	public float radius;
	final public float pi = 3.414f;
	public float area;
	public void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter radius");
		radius = scan.nextFloat();
		
	}
	
	public void compute() {
		area = pi*radius*radius;
	}
	public void display()
	{
		System.out.println("Area of circle is "+ area);
	}	
	
	
}



public class MixedProjectpart1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r1 = new Rectangle();
		r1.input();
		r1.compute();
		r1.display();
		
		Square s1 = new Square();
		s1.input();
		s1.compute();
		s1.display();
		
		Circle c1 = new Circle();
		c1.input();
		c1.compute();
		c1.display();

	}

}
