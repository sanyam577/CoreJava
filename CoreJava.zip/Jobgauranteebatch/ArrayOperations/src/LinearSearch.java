import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] ar = {45,60,85,70,63};
		System.out.println("Enter the Key");
		Scanner scan=new Scanner(System.in);
		int key = scan.nextInt();
		boolean flag = false;
		for(int i=0; i<ar.length;i++) {
			if(key==ar[i]) {
				System.out.println("We found the key "+ key+ " at index "+i);
				flag = true;
				break;
			}
			
		}
		if(flag==false) {
			System.out.println("Key not found");
		}

	}

}
