package in.ineuron.main;

public class question1 {
	public static void main(String args[]) {
		int n = 11;
		for(int i=0; i<n; i++) {
			for(int j=0; j<n; j++) {
				
				if( (i==0 || i==(n-1)|| j==(n-1)/2)) { //I
				System.out.print("*");
				
				}
				else {
					System.out.print(' ');
				}
				
			}
			 System.out.print(' ');
            for(int j=0; j<n; j++) {
				
				if((j==0)||(j==(n-1))|| (i==j)) { //N
				System.out.print("*");
				
				}
				else {
					System.out.print(' ');
				}
				
			}
            System.out.print(' ');
             for(int j=0; j<n; j++) {
				
				if( i==0 || i==(n-1)||j==0 || i==(n-1)/2) { //E
				System.out.print("*");
				
				}
				else {
					System.out.print(' ');
				}
				
			}
             System.out.print(' ');
             
             for(int j=0; j<n; j++) {
 				
 				if( (j==0&&i<(n-1)) || (j==(n-1)&&i<(n-1)) || (i==(n-1)&&j>0&&j<(n-1)) ) { //U
 				System.out.print("*");
 				
 				}
 				else {
 					System.out.print(' ');
 				}
 				
 			}
              System.out.print(' ');
              
              for(int j=0; j<n; j++) {
  				
  				if( j==0 || (i==0&&j<(n-1)) || (j==(n-1)&&i>0&&i<(n-1)/2) || (i==(n-1)/2&&j<(n-1)) 
  						|| (i==j&&i>=(n-1)/2)) {
  				System.out.print("*");     //R
  				
  				}
  				else {
  					System.out.print(' ');
  				}
  				
  			}
               System.out.print(' ');
              
			//this is O
			for(int j=0; j<n; j++) {
				
				if( (i==0&&j>0&&j<(n-1))|| (j==0&&i>0&&i<(n-1)) || (j==(n-1)&&i>0&&i<(n-1))
						|| (i==(n-1)&&j>0&&j<(n-1)) ) {
				System.out.print("*"); //O
				
				}
				else {
					System.out.print(' ');
				}
				
			}
			System.out.print(' ');
			
            for(int j=0; j<n; j++) {
				
				if((j==0)||(j==(n-1))|| (i==j)) { //N
				System.out.print("*");
				
				}
				else {
					System.out.print(' ');
				}
				
			}
			
		
			System.out.println();
		}
	}

}
