//XXXvalue() method is used to convert wrapper object into primitive type
 // XXX can be a byte , short, int , long, float , double
public class xxxValueMethod_Wrapper3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer i = new Integer(130);  //Wrapper 
		
		
		System.out.println(i.byteValue()); //-126 //primitive  // result = minrange+(total -maxrange -1) = -128 + 130 - 127 -1 = -126
		System.out.println(i.shortValue()); //130
		System.out.println(i.intValue()); //130
		System.out.println(i.longValue());
		System.out.println(i.floatValue());
		System.out.println(i.doubleValue());
		
		
		//character is bit different from others
		
		Character c = new Character('y'); //it only takes character type values while other wrapper class can take string value too 
		System.out.println(c.charValue()); //y
		
		Boolean b = new Boolean("True");  // it can take string value and normal true false also // without caring about the case if value is true it will return true otherwise in all cases it will return flase
		//Boolean b = new Boolean("true");
		//Boolean b = new Boolean(true);
		System.out.println(b.booleanValue()); // true
		
	}

}
