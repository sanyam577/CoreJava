//can we make our user defined class as immutable? ans. Yes
final class UserDefinedClass_Wrapper1 {
	int i; 
	UserDefinedClass_Wrapper1(int i){
		this.i =i;
	}
	public UserDefinedClass_Wrapper1 modify(int i) {
		if(this.i == i) 
			return this;
		
		else 
			return new UserDefinedClass_Wrapper1(i);
	}

	public static void main(String[] args) {
		UserDefinedClass_Wrapper1 t1 = new UserDefinedClass_Wrapper1(10);
		UserDefinedClass_Wrapper1 t2 = t1.modify(10);
		UserDefinedClass_Wrapper1 t3 = t1.modify(100);
		UserDefinedClass_Wrapper1 t4 = t3.modify(100);
		
		System.out.println(t1==t2);
		System.out.println(t1==t3);
		System.out.println(t2==t3);
		System.out.println(t3==t4);

	}

}
