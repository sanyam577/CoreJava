//toString method is used to convert wrapper object into String object
//                      BOTH RESULT WILL BE SAME
//we can also use .toBinaryString(), .toOctalString(), .toHexString() methods to convert Wrapper object into String object and then binary or other operations will be performed
 public class toStringMethod_Wrapper5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String res1 = Integer.toString(7,2); //7 is of wrapper object type it will converted into string and then binary operation will be performed
		String res2 = Integer.toString(10,8); //10 is of wrapper object type it will converted into string and then octal operation will be performed
		String res3 = Integer.toString(10,16);// 10 is of wrapper object type it will converted into string and then hexadecimal operation will be performed
		
		System.out.println(res1);//111
		System.out.println(res2);//12
		System.out.println(res3);//a
		
		System.out.println();
		
		String s1 = Integer.toBinaryString(7);
		String s2 = Integer.toOctalString(10);
		String s3 = Integer.toHexString(10);
		
		System.out.println(s1);	//111
		System.out.println(s2);	//12
		System.out.println(s3);//a
		
		
		
		

	}

}
