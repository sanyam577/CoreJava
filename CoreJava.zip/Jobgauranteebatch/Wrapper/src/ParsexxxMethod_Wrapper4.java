// parsexxx convert String object to primitive
public class ParsexxxMethod_Wrapper4 {
	public static void main(String []args) {
		
		int i = Integer.parseInt("10"); //"10" is a string value and it will be converted into int type by using parsexxx() method
		System.out.println(i);
		
		boolean b = Boolean.parseBoolean("true");
		System.out.println(b);
		
		//char c = Character.parseCharacter("u"); //The method parseCharacter(String) is undefined for the type Character
		//System.out.println(c);
		
		double d = Double.parseDouble("10.5");
		System.out.println(d);
		
	}

}
