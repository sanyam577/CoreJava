// valueOf() method is used to convert string or primitive values into wrapper object
public class ValueOf_Wrapper2 {

	public static void main(String[] args) {
		
		Integer i1 = Integer.valueOf(10); //primitive to wrapper (here 10 is of int type and we are going to convert it into Integer)
		System.out.println(i1);
		
		Integer i2 = Integer.valueOf("10"); // "10" is of string type and we are going to convert it into Integer (wrapper class)
		System.out.println(i2);             

		
		Boolean i3 = Boolean.valueOf("ramji"); // "ramji" is of string type and we are going to convert it into Boolean (wrapper class)
		System.out.println(i3);                  // if it is not true then in all case it will return false in this case its false
		
	//	Integer i4 = Integer.valueOf("ten"); // "10" is of string type and we are going to convert it into Integer (wrapper class)
	//	System.out.println(i4);   //Return: NumberFormatException
		
		Integer i5=Integer.valueOf("1111");
		 System.out.println(i5);//1111
		 
		Integer i6=Integer.valueOf("1111",2);
		 System.out.println(i6);//15
		 
	//	Integer i7=Integer.valueOf("1111",37);  //in this case limit od redix is from 2 to 36
	//	 System.out.println(i7);//RE:NumberFormatException
		 
		 Double d1=Double.valueOf(10.5);
		 System.out.println(d1);
		 
		 Character c=Character.valueOf('a');
		 System.out.println(c);
		 
		 Boolean b=Boolean.valueOf(true);
		 System.out.println(b);
		
		
		

	}

}
