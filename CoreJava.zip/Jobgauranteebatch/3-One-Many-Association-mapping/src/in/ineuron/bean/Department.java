package in.ineuron.bean;

//Target object
public class Department {
	
	private String depId;
	private String depname;
	
	//HAS-A relationship
	private Employee[] emps;

	//constructor injection
	public Department(String depId, String depname, Employee[] emps) {
		super();
		this.depId = depId;
		this.depname = depname;
		this.emps = emps;
	}
	
	public void getDepartmentDetails() {
		System.out.println("Department Details ::");
		System.out.println("-------------------");
		System.out.println(" ");
		System.out.println("Department Id: "+depId);
		System.out.println("Department Name: "+ depname);
		System.out.println(" ");
		
		
		System.out.println("Employees details are:: ");
		System.out.println("---------------------");
		System.out.println(" ");
		
		for(Employee employee : emps ) {
		System.out.println("Employee Id :: " +employee.eid);
		System.out.println("Employee name :: "+employee.ename);
		System.out.println("Employee address :: "+employee.eaddr);
		System.out.println(" ");
		
		}
		
	
	}

}
