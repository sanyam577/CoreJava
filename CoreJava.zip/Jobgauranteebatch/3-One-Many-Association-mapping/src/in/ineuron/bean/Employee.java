package in.ineuron.bean;

public class Employee {

	 String eid;
	 String ename;
	 String eaddr;
	
	

	public Employee(String eid, String ename, String eaddr) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.eaddr = eaddr;
		
	}
	
		
	
	
	
	

}
