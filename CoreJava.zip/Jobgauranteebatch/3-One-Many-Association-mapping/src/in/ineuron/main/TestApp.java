package in.ineuron.main;

import in.ineuron.bean.Department;
import in.ineuron.bean.Employee;

public class TestApp {

	public static void main(String[] args) {
		Employee e1= new Employee("10", "Sachin", "Mumbai");
		Employee e2= new Employee("07", "Dhoni", "RCB");
		Employee e3= new Employee("18", "Kholi", "CSK");
		
		Employee[] emps = new Employee[3];
		emps[0] = e1;
		emps[1] = e2;
		emps[2] = e3;
		
		Department department = new Department("IPL23", "BCCI", emps);
		department.getDepartmentDetails();
		
	}

}
