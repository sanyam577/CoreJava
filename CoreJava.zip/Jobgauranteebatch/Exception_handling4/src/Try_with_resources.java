//import java.util.Scanner;
import java.io.*;
/*
public class Try_with_resources {

	public static void main(String[] args) {
		try(Scanner scanner = new Scanner(System.in)){
			System.out.println("hello");
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
*/

//normally we write finally at last to print something which is after catch block and it close all resources

/* 
public class Try_with_resources {

	public static void main(String[] args) {
          BufferedReader br=null;
try{
      br=new BufferedReader(new FileReader("abc.txt"));
          }catch(IOException ie){
           ie.printStackTrace();
}
         finally{
                  try{
                       if(br!=null){
                            br.close();
                               }
                  }
                    catch(IOException ie){
                                ie.printStackTrace();
                          }
                }
  }
	}
*/



public class Try_with_resources {

	public static void main(String[] args) {
       try(BufferedReader br = new BufferedReader(new FileReader("sample.txt"))){
    	  // br = new BufferedReader(new FileReader("output.txt")); CE: can't reassign a value to br because br is final
       } 
       //once the control reaches the end of try block automatically br will be closed 
       // br.close() will execute automatically and resource will be closed
       catch(Exception e) {
    	   e.printStackTrace();
       }

  }
	}



























