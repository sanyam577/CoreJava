import java.io.*;

public class Multi_catchBlock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        try {
        	//risky code
        	;;;;;;
        	;;;;;
        	;;;;;;
        	;;;;;;
        	new BufferedReader(new FileReader("sample.txt"));
        }
        catch(ArithmeticException| NullPointerException e) {
        	//handling code
        	e.printStackTrace();
        }
        catch(ClassCastException| IOException e) {
        	//handling code
        	e.printStackTrace();
        }
        
        /*In multicatch block,there should not be any relation b/w exception types(either 
        		child to parent or parent to child or same type) it would result in compile time 
        		error.
        		
        		
        		catch( ArithmeticExeption | Exception e){
        		e.printStackTrace();
        		 }
        		 
        		 
        		 
        		Output:CompileTime Error
        		
        		
        		*/
	
	}

}
