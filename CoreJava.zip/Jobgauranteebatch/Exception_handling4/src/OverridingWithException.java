// Rules of Overriding when exception is involved
import java.io.*;

/*
class Parent{
	public void m1() {
		
	}
}

class Child extends Parent{
	@Override
	public void m1()throws Exception{ //below is the reason of this error 
		//While Overriding if the child class method throws any checked exception cumpulsarily the parent class 
		//method should throw the same checked exception or its parent otherwise we will get Compile Time Error.
		
	}
}
public class OverridingWithException {

	public static void main(String[] args) {
		
	}

}
*/



class Parent{
	public void m1() {
		
	}
}

class Child extends Parent{
	@Override
	public void m1()throws NullPointerException {   //There are no restrictions on UncheckedException.

		
	}
}
public class OverridingWithException {

	public static void main(String[] args) {
		
	}
		
	
}
	




/* there are some other cases:-
 * 
 * parent: public void methodOne() throws Exception{}
child : public void methodOne()
output: valid


parent: public void methodOne(){} 
child : public void methodOne() throws Exception{}
output: invalid  because child have checked exception parent dont't have


parent: public void methodOne()throws Exception{}
child : public void methodOne()throws Exception{}
output: valid because both have checked exception


parent: public void methodOne()throws IOException{}
child : public void methodOne()throws IOException{}
output: valid valid because both have checked exception


parent: public void methodOne()throws IOException{}
child : public void methodOne()throws FileNotFoundException,EOFException{}
output: valid because FileNotFoundException,EOFException are child of IOException


parent: public void methodOne()throws IOException{}
child : public void methodOne()throws FileNotFoundException,InterruptedException{}
output: invalid because InterruptedException is not child of IOException


parent: public void methodOne()throws IOException{}
child : public void methodOne()throws FileNotFoundException,ArithmeticException{}
output: valid because ArithmeticException is a unchecked exception so no problem


parent: public void methodOne()
child : public void methodOne()throws ArithmeticException,NullPointerException,RuntimeException{}
output: valid because all are unchecked exception 


parent: public void methodOne()throws IOException{}
child : public void methodOne()throws Exception{}
output: invalid because IOException is child of Exception and is with parent class


parent: public void methodOne()throws Throwable{}
child : public void methodOne()throws IOException{}
output: valid IOException is grandson of Throwable
*/
 * 
 */

