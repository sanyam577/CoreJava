import java.util.Scanner;

//try-catch pair to handle exception 

public class EH4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Calculator.com");
		Scanner scan = new Scanner(System.in);
		
		try {
	
		System.out.println("Enter a number"); 
		int x = scan.nextInt();
		System.out.println("Enter a number as divisor"); 
		int y = scan.nextInt();
		
		int res = x/y;
		
		System.out.println("here is the result "+ res);}
		
		catch(ArithmeticException ae) {
			System.out.println("Avoid entering zero");
		}
		
		int [] a = null;
		
		try {
		System.out.println("Enter the size of array");
		int size = scan.nextInt();
		a = new int[size];
		}
		catch(NegativeArraySizeException nase) {
			System.out.println("size must be a positive number");
		}
		
		try {
		System.out.println("Enter the element to be added in that array");
		int ele = scan.nextInt();
		System.out.println("Enter the position");
		int pos = scan.nextInt();
		
		a[pos]= ele;
		
		System.out.println("element "+ele+ "is inserted at position "+pos+ " sucessfully");
		
		}
		
		catch(ArrayIndexOutOfBoundsException ai) {
			System.out.println("Enter postion in between the size of array");
		}
		
		catch(Exception e) { // this is general case if any exception is not resolved it will come into picture 
			System.out.println("Wrong input");
		}
		System.out.println("Disconnected sucessfully");
	
	}

}
