import java.util.Scanner;

public class EH2 {

	public static void main(String[] args) {
		
		System.out.println("Calculator.com");
		try {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a number"); 
		int x = scan.nextInt();
		System.out.println("Enter a number as divisor"); 
		int y = scan.nextInt();
		
		int res = x/y;
		
		System.out.println("here is the result "+ res);
		
		System.out.println("Enter the size of array");
		int size = scan.nextInt();
		int [] a = new int[size];
		System.out.println("Enter the element to be added in that array");
		int ele = scan.nextInt();
		System.out.println("Enter the position");
		int pos = scan.nextInt();
		
		a[pos]= ele;
		
		System.out.println("element "+ele+ "is inserted at position "+pos+ " sucessfully");
		
		
		}
		catch(Exception e) {                            //Exception is a class including all type of exception 
			System.out.println("Illegal entry ");    //in this program there are 3 types of exception : 
			                                              //ArithmeticException (because of zero as divisor), 
		}	                                             //NegativeArraySizeException (because we can't enter size of array as negative number)
			                                                //: InputMismatchException (let suppose if we input element added as a float number 10.25f then this error will come) this is different case 
		                                                  //: ArrayIndexOutOfBoundsException (if we enter the position greater than or less than the size of array)
		
		System.out.println("Program is terminates");
		

	}

}
