import java.util.Scanner;

public class EH1 {

	public static void main(String[] args) {
		System.out.println("Calculator.com");
		try {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a number"); 
		int x = scan.nextInt();
		System.out.println("Enter a number as divisor"); 
		int y = scan.nextInt();
		
		int res = x/y;
		
		System.out.println("here is the result"+ res);
		}
		
		catch(Exception e) { //Exception is an inbuilt class including all type of exception
			
			System.out.println("Illegal entry don't enter 0 as divisor");
		}
		
		System.out.println("Program is terminates");
		

	}

}
