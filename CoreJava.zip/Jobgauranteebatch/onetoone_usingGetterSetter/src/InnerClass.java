
public class InnerClass {
	int num;
	
	A obj = new A(); //we can create object of inner class in the same class in which it is present
	
	public void display() {
		System.out.println("Hi Thanos is side");
		obj.config();
	}
	
	class A{ //This is our inner class (class inside another class)
		
		public void config() 
		{	
		System.out.println("Inner class");
		
		}
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InnerClass in = new InnerClass();
		in.display();

	}

}
