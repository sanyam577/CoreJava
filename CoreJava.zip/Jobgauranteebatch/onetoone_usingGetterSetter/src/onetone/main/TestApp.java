package onetone.main;

import onetoone.bean.Account;
import onetoone.bean.Employee;

public class TestApp {
	public static void main(String[] args) {
	Account account = new Account();
	account.setaType("Saving");
	account.setaNo(12554);
	
	Employee employee = new Employee();
	employee.seteName("Ram");
	employee.seteId("859S");
	employee.setAccount(account);
	
	System.out.println("Employee Details are :: ");
	System.out.println("Name :" +employee.geteName());
	System.out.println("ID :"+ employee.geteId());
	System.out.println("Accoubt type :"+employee.getAccount().getaType());
	System.out.println("Accoubt Number :"+employee.getAccount().getaNo());
	
}
}