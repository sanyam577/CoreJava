import java.util.*;
//The main objective of Generics is to provide Type-Safety and to resolve Type-Casting problems.
//Type-Safety : Arrays are always type safe
//to achieve this we use generics in collection

public class G1 {

	public static void main(String[] args) {
		ArrayList<String> a1 = new ArrayList<String>(); //For this ArrayList we can add only string type of objects by 
		   a1.add("Sachin");                          //mistake if we are trying to add any other type we will get 
		   a1.add("Dhoni");                      //compile time error that is through generics we are getting type safety.

		   String name1 = a1.get(0); 
		   String name2 = a1.get(1);
	}

}
