//we can create a generic class of our own 

class Gen<T>
{
     T obj; //T---->Integer, String,Double,.......
     //Parameterized constructor 
      Gen(T obj){
	   this.obj = obj;
     }
    public void show() {
    	System.out.println("The type of object is :: "+obj.getClass().getName());
    }    
    public T getObj() {
    	return obj;
    } 
}
public class UserDefined_Generics3 {

	public static void main(String[] args) {
		Gen<Integer> g1 = new Gen<Integer>(10);
		g1.show();
		System.out.println(g1.getObj());
		
		Gen<String> g2 = new Gen<String>("Nil-Kamal");
		g2.show();
		System.out.println(g2.getObj());
		
		Gen<Double> g3 = new Gen<Double>(10.5);
		g3.show();
		System.out.println(g3.getObj());		
	}

}

//interface Calculator{}
//class Casio implements Calculator{}
//Calculator c1 = new Casio();
//System.out.println(c1.getName().getClass())  //this function will give you the name of run time object
//Output:- Casio 
