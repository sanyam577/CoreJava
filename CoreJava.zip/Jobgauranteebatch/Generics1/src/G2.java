//BaseParameter :--> List
//TypeParameter :--> <String>
import java.util.*;
public class G2 {

	public static void main(String[] args) {
		
		List<String> a1 = new ArrayList<String>(); //Valid //List is parent (means BaseParameter can be of parent type) 
        Collection<String> a2 = new ArrayList<String>(); //Valid BaseParameter can be of grandparent type
      //ArrayList<Object> a3 = new ArrayList<String>(); //Invalid TypeParameter can not be of parent type here Object is 
                                                        //parent of string
        ArrayList<Integer> a4 = new ArrayList<Integer>();
        
	}

}
