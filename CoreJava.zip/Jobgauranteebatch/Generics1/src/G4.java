//X --> class means, we can pass either X type or its Child Type
//X --> interface means , we can pass either X or its implementation class
//here in this program we put a limit on user define generic by using extends keyword (here for a class or for a 
//interface we have to use extends not implements)
//class Demo<T extends X>{
	
//}

class Demo<T extends Number>{
	
}

class Sample<T extends Runnable>{
	
}

public class G4 {

	public static void main(String[] args) {
		Demo<Number> d1 = new Demo<Number>(); //parent
		Demo<Integer> d2 = new Demo<Integer>(); //child 
	//	Demo<String> d3 = new Demo<String>(); // this will give error because string in not a child of Number class
		
		Sample<Runnable> s1 = new Sample<Runnable>(); //parent 
		Sample<Thread> s2 = new Sample<Thread>(); //child
	}

}
