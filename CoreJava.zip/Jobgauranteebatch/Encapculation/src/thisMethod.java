class Student3{
	private int age;
	private String name;
	private String city;
	
	public Student3(int age, String name, String city) {
		this();
		 
		this.age = age;
		this.name = name;
		this.city = city;
	}
	public Student3() {
		this("NITIN");
		
		name = "Mohan";
		city = "Gokul";
	}
	
	public Student3(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public String getName() {
		return name;
	}
	public String getCity() {
		return city;
	}
	
	
} 


public class thisMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student3 st3= new Student3(24, "Shyan", "Vrindavan");
		
		System.out.println(st3.getAge());
		System.out.println(st3.getName());
		System.out.println(st3.getCity());
		
		Student3 st4= new Student3();
		System.out.println(st3.getAge());
		System.out.println(st3.getName());
		System.out.println(st3.getCity());
		
		
		

	}

}
