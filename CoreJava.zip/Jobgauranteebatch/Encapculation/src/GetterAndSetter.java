class Student1{
	private int age;
	private String name;
	private String city;
	
	//we can create common setter in which we can put all type of parameter
	public void setData(int age, String name, String city) {
		this.age = age;
		this.name = name;
		this.city = city;
	}
	int getAge() {
		return age;
	}
	String getName() {
		return name;
	}
	String getCity() {
		return city;
	}
	
	
}




public class GetterAndSetter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student1 st1 = new Student1();
		// we can pass all arguments in one line because of common setter
		st1.setData(17, "Hari", "Basti");
		System.out.println(st1.getAge());
		String name = st1.getName();
		System.out.println(name);
		System.out.println(st1.getCity());

	}

}
