
   	class Student{
		private int age;
		private String name;
		private String city;
		
		void setAge(int age) {
		     this.age = age;
		     
		     }
		int getAge() {
			return age;
		}
		
		void setName(String name) {
			this.name = name;
		}
		String getName() {
			return name;
		}
		
		void setCity(String city) {
			this.city = city;
		}
		String getCity() {
			return city;
		}
		
	
			
	}
	
	
	public class Encapculation1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student s = new Student();
		
		s.setAge(16);
		int age = s.getAge();
		System.out.println(age);
		
		s.setName("Hari");
		String name = s.getName();
		System.out.println(name);
		
		s.setCity("Baikunth");
		String city = s.getCity();
		System.out.println(city);
		

	}

}
