class Student2{
	private int age;
	private String name;
	private String city;
	
	//here we are using constructor that's why class name is same as method name "Student2"
	public Student2(int age, String name, String city) {
		this.age = age;
		this.name =name;
		this.city= city;	
		}
	
	
	public int getAge() {
		return age;
	}
	public String getName() {
		return name;
	}
	public String getCity() {
		return city;
	}
	
	
}



public class Constuructor {

	public static void main(String[] args) {
		// because of constructor we will have to pass all arguments while creating object 
		Student2 st1= new Student2(17, "Hari", "Gokul");
		 
		System.out.println(st1.getAge());
		System.out.println(st1.getName());
		System.out.println(st1.getCity());

	}

}
