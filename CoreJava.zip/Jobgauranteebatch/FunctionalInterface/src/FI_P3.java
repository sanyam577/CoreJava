import java.util.function.*;

/*
public class FI_P3 {

	public static void main(String[] args) {
		int[] arr = {0,5,10,15,20,25,30};
		int[] arr1 = new int[arr.length];
		int j=0;
		for(int i=0; i<arr.length; i++) {
			if(arr[i]>=10) {
				arr1[j]=arr[i];
				j++;
			}
		}
		for(int ele: arr1) {
			System.out.print(ele +" ");
		}
		
	}

}
*/


public class FI_P3 {
	public static void main(String[] args) {
		int[] arr = {0,5,10,15,20,25,30};
		System.out.println("Elements greater than 10 are : ");
		Predicate<Integer> p1 = (i) -> i>10;
		m1(p1,arr);
		
		Predicate<Integer> p2 = (i) -> i%2==0;
		System.out.println("Elements which are even : ");
		m1(p2, arr);
		
		//we have three more default methods present in predicate interface 1. .and() 2. .or() 3. .negate()
		System.out.println("Elements which are greater than 10 and even : ");
		m1(p1.and(p2), arr);
		
		System.out.println("Elements which are greater than 10 or should be even number : ");
		m1(p1.or(p2), arr);
		
		System.out.println("Elements which are not even are : ");
		m1(p2.negate(), arr); //it will reverse the result of p2
		
		}
	
	public static void m1(Predicate<Integer> p, int[] x) {
		for(int ele: x)
			if(p.test(ele)) //for predicate p1 (ele)-> ele>10;     for predicate p2 (ele)-> ele%2==0;
				System.out.println(ele);
	}
}










