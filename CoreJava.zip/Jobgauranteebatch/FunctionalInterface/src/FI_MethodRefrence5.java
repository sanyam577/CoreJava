//Method reference is used to refer method of functional interface. It is compact and easy form of lambda expression.
//Each time when you are using lambda expression to just referring a method, you can replace your lambda expression with 
//method reference.
//Java Method reference is a Lambda Expression that is used to refer a method without invoking it.
//The Method References are similar to Lambda expressions, that they require a target type. But instead of providing 
//implementation of a method, they refer to a method of an existing class or object.


/*
//using lambda expression
public class FI_MethodRefrence5 {

	public static void main(String[] args) {
		Runnable r = ()-> {
			           for(int i=1; i<=5; i++) {
			        	   System.out.println("Child Thread");
			           }
		           };
		Thread t = new Thread(r);
		t.start();
		
	     for(int i=1; i<=5; i++) 
	     {
	      System.out.println("Main Thread");
	     }
	}
}
*/


/*
//method reference

public class FI_MethodRefrence5 {
	
	public static void m1() {
		for(int i=1; i<=5; i++) {
     	   System.out.println("Child Thread");
        }
		
	}
	public static void main(String[] args) {
		Runnable r = FI_MethodRefrence5::m1; //method binding
			   
						
		Thread t = new Thread(r);
		t.start();
		
	     for(int i=1; i<=5; i++) 
	     {
	      System.out.println("Main Thread");
	     }
	}

}
*/

/*
interface Interf{
	public void m1(int i);
}

class MyInterf implements Interf{
	public void m1(int i) {
		System.out.println("From method refrence");
	}
}

public class FI_MethodRefrence5 {
	
	public static void main(String [] args) {
		
		Interf i = x-> System.out.println("From Lambda expression");
		i.m1(100);
		//or
		Interf i2 = new MyInterf()::m1;  
		i2.m1(10);
			
	}
}


*/

interface Interf{
	public void m1(int i);
}


public class FI_MethodRefrence5 {
	//logic written by coder
	public void m1(int i) {
		System.out.println("From method refrence");
	}
	
	public static void main(String [] args) {
		
		Interf i = x-> System.out.println("From Lambda expression");
		i.m1(100);
		//or
		System.out.println();
		
		Interf i2 = new FI_MethodRefrence5()::m1;  
		i2.m1(10);
			
	}
}



















