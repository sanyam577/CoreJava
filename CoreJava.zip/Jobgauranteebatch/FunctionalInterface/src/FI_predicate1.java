//A Functional Interface is an Interface which allows only one Abstract method within the Interface scope. 
//There are some predefined functional interface in Java like Predicate, consumer, supplier etc. 
//The return type of a Lambda function (introduced in JDK 1.8) is a also functional interface.

//The Functional Interface PREDICATE is defined in the java.util.function package. 
//It improves manageability of code, helps in unit-testing them separately, and contain some methods 


import java.util.function.Predicate;


/*
class MyPredicate implements Predicate<Integer>
{
	@Override 
	public boolean test(Integer i) {   //test(T t) : Is a abstract method present in Predicate functional interface it evaluates
		if(i>10)                      //this predicate on the given argument.boolean test(T t) is true or false
			return true;                                // test(T t) 
		else	                                       //Parameters:
			return false;	                          // t - the input argument
				                                      // Returns:
				                                     //true if the input argument matches the predicate, otherwise false		
	}
}

public class FI_predicate1 {

	public static void main(String[] args) {
		
		Predicate p = new MyPredicate();
		System.out.println(p.test(10)); //false 
		System.out.println(p.test(100)); //true
	}

}
*/







//now we are going to use lambda expression
public class FI_predicate1 {

	public static void main(String[] args) {
		
		Predicate<Integer> p = (i)-> i>10 ;  // Predicate<Integer> p :- object creation, here 'p' is predicate (variable)
		                                     // (i) :- is method parameter 
		                                     //-> lambda expression symbol
		                                     //i>10 :- lambda expression body we can also write it in curly bracket {i>10}
		
		
		System.out.println(p.test(10)); //false 
		System.out.println(p.test(100)); //true
	}

}

















