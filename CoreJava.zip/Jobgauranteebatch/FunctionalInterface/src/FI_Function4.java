import java.util.function.Function;

/*
The Function Interface is a part of the java.util.function package which has been introduced since Java 8, 
to implement functional programming in Java. It represents a function which takes in one argument and produces a result.
Hence this functional interface takes in 2 generics namely as follows:

T: denotes the type of the input argument
R: denotes the return type of the function
4 type of methods: 1. apply()
                   2. andThen()
                   3. compose()
                   4. identity()
*/
/*
//apply()
class MyFunction implements Function<String, Integer>{
	@Override
	public Integer apply(String name) { //apply(T t) is a method present in Function interface 
		return name.length();
	}
}

public class FI_Function4 {

	public static void main(String[] args) {
		Function<String, Integer> f= new MyFunction();
		int output = f.apply("sachin");
		System.out.println(output);
		
	//	System.out.println("sachin".length());
		

	}

}
*/

/*
//apply()
public class FI_Function4 {

	public static void main(String[] args) {
		Function<String, Integer> f= (name)-> name.length(); //by using lambda expression
		int output = f.apply("sachin");
		System.out.println(output);
		
	//	System.out.println("sachin".length());
		

	}

}
*/
/*
//andThen() : parameterized function will be executed after the first one
public class FI_Function4 {

	public static void main(String[] args) {
		Function<Integer, Double> half = (a) -> a/2.0;
		half = half.andThen(a-> 3*a);
		System.out.println(half.apply(10));

	}

}
*/

// compose(): parameterized function will be executed first and then the first one.

public class FI_Function4 {

	public static void main(String[] args) {
		Function<Integer, Double> half = (a) -> a/2.0;
		half = half.andThen(a-> 3*a);
		System.out.println(half.apply(10));

	}

}






















//Note: when to use predicate and when to go for function?
//Predicate: To implement some condition checks we should go for predicate
//Function: To perform some operation and to return some result we should go for Function