import java.util.function.Predicate;

/*
class MyPredicate2 implements Predicate<String>{
	@Override
	public boolean test(String name) {
		if(name.length()>3)
			return true;
		else 
			return false;
	}
}

public class FI_P2 {

	public static void main(String[] args) {
		Predicate<String> p = new MyPredicate2();
		System.out.println(p.test("Ram"));
		System.out.println(p.test("Sita"));
		
		
		
	//	boolean b = p.test("Ram");
	//	System.out.println(b);
    //	boolean b1 = p.test("Sita");
   //	System.out.println(b1);
		

	}

}
*/







//Now we are going to use lambda expression
public class FI_P2 {

	public static void main(String[] args) {
		Predicate<String> p = (name)->name.length()>3; 
		
		System.out.println(p.test("Ram"));
		System.out.println(p.test("Sita"));
	
	}

}