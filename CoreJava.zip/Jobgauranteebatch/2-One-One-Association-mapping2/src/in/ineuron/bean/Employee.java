package in.ineuron.bean;

public class Employee {

	private String eid;
	private String ename;
	private String eaddr;
	
	Account account;

	public Employee(String eid, String ename, String eaddr, Account account) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.eaddr = eaddr;
		this.account = account;
	}
	
	public void getEmployeeDetails() {
		System.out.println("Employee Details are :: ");
		System.out.println("EmpId: "+eid);
		System.out.println("Ename: "+ename);
		System.out.println("Eaddr: "+eaddr);
		System.out.println("Account Details are:: ");
		System.out.println("Account no. "+account.accNo);
		System.out.println("Account holder name. "+account.accName);
		System.out.println("Account type "+account.accType);
		
	
	}
	
	

}
