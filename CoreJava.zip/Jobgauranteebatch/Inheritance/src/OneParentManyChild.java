// one parent class may have many child (this is not hierarchical inheritance) 
class Demo5{
	String name= "Shree Hari";
	int age = 23456323;
	
	void disp() {
		System.out.println("Demo " + name + age);
     
	}
 class Demo6 extends Demo5 //parent is Demo5 
  {
	
	}	
 class Demo7 extends Demo5 //parent is Demo5 
 {
	 
 }
 //Demo6 can also be a parent
 class Demo8 extends Demo6{ // Demo6 is parent and Demo5 is grand parent
	 
 }
 
 //multiple inheritance is not allowed(a class can't have multiple parents) 
 // Demo9 extends Demo6 Demo7 {
 //                             }        
 // (here Demo9 is trying to acquire properties of two parents Demo6 and Demo7) 
 // if Demo6 has a property int i=10 and Demo7 has a property int i=20 how Demo9 can have two values of int i. 
 
 
 
 //**Cyclic inheritance is not possible**
 
 //class Demo123 extends Demo234{
	 
 //}
 //class Demo234 extends Deno123{
	 
 //}
 
 
}


public class OneParentManyChild {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
