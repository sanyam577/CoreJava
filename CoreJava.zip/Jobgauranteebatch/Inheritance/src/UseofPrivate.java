

class Parent11{
	 private String name;
	void disp1() {
		System.out.println("Parent ");
	}
}
	class Child11 extends Parent11 {
		void disp2() {
			name = "Karishna";// private members will not participate in inheritance that,s why this error 
		}
	}
	

public class UseofPrivate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child11 c = new Child11();
              c.disp1();
	}

}
