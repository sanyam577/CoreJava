class Parentt1 {
	int a, b;
	Parentt1(){
		a=10;
		b=20;
		System.out.println("Parentt Constructor");
	}
	
	Parentt1(int a, int b){
		this.a = a;
		this.b = b;
		System.out.println("Parentt paramertize constructor");
	}
	
}
class Childd1 extends Parentt {
	int x, y;
	
	Childd1(){
		this(111,222); 
		x= 100;
		y= 200;
		System.out.println("child zero param constructor");
	}
	
	Childd1(int x, int y){
		super(x,y);
		this.x = x;
		this.y = y;
		System.out.println("child param constructor");
	}
	
	void disp() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(x);
		System.out.println(y);
	}



}


public class Constructor_in_inheritance_using_thisPart3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Childd1 ch1 = new Childd1();
		ch1.disp();
		Childd1 ch2 = new Childd1(1000, 2000);
		ch2.disp();

	}

}
