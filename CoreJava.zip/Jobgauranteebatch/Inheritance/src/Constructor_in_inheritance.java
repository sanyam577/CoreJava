class Parentt {
	int a, b;
	Parentt(){
		a=10;
		b=20;
		System.out.println("Parentt Constructor");
	}
	
	Parentt(int a, int b){
		this.a = a;
		this.b = b;
		System.out.println("Parentt paramertize constructor");
	}
	
}
class Childd extends Parentt {
	int x, y;
	
	Childd(){
		//super(); super method is active behind the scene
		x= 100;
		y= 200;
	}
	
	Childd(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	void disp() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(x);
		System.out.println(y);
	}
}




public class Constructor_in_inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Childd ch1 = new Childd(); //when we create object memory of x,y and a,b(Parentt is a parent
		                 //class for Childd) is created . Now control will in Childd constuctor and there is inbuilt 
		             //method called super(), it will take the control to Parentt constructor , after execution it 
		                    //will return back to childd constructor 
		ch1.disp(); 

	}

}
