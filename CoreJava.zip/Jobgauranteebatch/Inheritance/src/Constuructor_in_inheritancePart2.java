class Parenttt {
	int a, b;
	Parenttt(){
		a=10;
		b=20;
		System.out.println("Parentt Constructor");
	}
	
	Parenttt(int a, int b){// control will come here from parameterize childd constructor because of super method 
		this.a = a;
		this.b = b;
		System.out.println("Parentt paramertize constructor");
	}
	
}
class Childdd extends Parenttt {
	int x, y;
	
	Childdd(){
		//super(); super method is active behind the scene
		x= 100;
		y= 200;
	}
	
	Childdd(int x, int y){
		super(x,y); // in this case we have to write super method and we have to pass to two parameters
		this.x = x;
		this.y = y;
	}
	
	void disp() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(x);
		System.out.println(y);
	}


}


public class Constuructor_in_inheritancePart2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Childdd ch2 = new Childdd(1000, 2000); // here we creating object of parameterize Childdd constructor ,
		                    //and because of super() method it will call Parenttt parameterize constructor too
		ch2.disp();

	}

}
