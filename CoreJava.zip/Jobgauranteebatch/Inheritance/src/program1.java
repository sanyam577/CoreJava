class Demo1 // extends Object class , if you write d. you will see all the properties and method of object class means Demo1 is also a child of Object class.
{                // means object class is parent of all class
	String name= "Shree Hari";
	int age = 23456323;
	
	void disp() {
		System.out.println("Demo " + name + age);
	}
	
}
//we use "extends" keyword to establish relation between two classes

class Demo2 extends Demo1 // Demo1 is parent of Demo2 
{
	
}
//multilevel inheritance
class Demo3 extends Demo2 // Demo2 is parent and Demo3 is child
{
	
}


public class program1 {

	public static void main(String[] args) {
		
		Demo2 demo = new Demo2();
		 demo.disp(); // this method is not present in Demo2 but we can use it by using "extends Demo1"
		 
		 //multilevel inheritance
		 Demo3 demoo = new Demo3();
		 demoo.disp();

	}

}
