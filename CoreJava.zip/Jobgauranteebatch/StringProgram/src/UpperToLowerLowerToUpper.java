import java.util.Scanner;

public class UpperToLowerLowerToUpper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a string ");
		String str1 = scan.nextLine();
		String str2 = "";

		for(int i=0; i<str1.length(); i++) {
			if(str1.charAt(i)>=97&&str1.charAt(i)<122) {
				str2 = str2 + (char)(str1.charAt(i)-32);
			}
			else {
				str2 = str2 + (char)(str1.charAt(i)+32);
			}
		}
		
		System.out.println("String is "+ str2);
		
	}

}
