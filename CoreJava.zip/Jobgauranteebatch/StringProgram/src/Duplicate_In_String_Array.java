
public class Duplicate_In_String_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [] arr = {"ramji", "sitaji", "Shivji", "parvatiji", "ramji"};
		
		for(int i=0; i<arr.length-1; i++ ) {
			for(int j=i+1; j<arr.length; j++) {
				if((arr[i]).equals(arr[j]) && i!=j) {
					System.out.println("Duplicate string is : "+arr[i]+ " at index "+ j); 
				}
			}
		}

	}

}
