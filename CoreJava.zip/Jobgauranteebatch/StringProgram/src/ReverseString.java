
public class ReverseString {

	public static void main(String[] args) {
		//iNeuron java to  avaj norueNi
		
	String	str1 = "iNeuron java batch";
	String str2 ="";
	
	for(int i= str1.length()-1; i>=0; i--) {
		str2 = str2 + (char)str1.charAt(i);
	}
      System.out.println(str2);
      
      //iNeuron java to norueNi avaj
      
      String s1 = "iNeuron java is in bengaluru";
      String s2 = "";
      
      String [] s3 = s1.split(" "); 
      
      for(String elem: s3) {
    	  
    	  for(int i=elem.length()-1; i>=0; i-- ) {
    		  s2 = s2 + (char)elem.charAt(i);
    	  }
    	  s2 = s2 + " ";
    	  
      }
      
      System.out.println(s2);
      
       
	}

}
