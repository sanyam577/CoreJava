import java.util.*;
public class CopyString {
public static void main(String args []) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter a string");
	//   String str1 = scan.nextLine();
	String str1 = scan.nextLine();
	String str2 = "";
	
	for(int i = 0; i<str1.length(); i++) {
		str2 = str2 + (char)str1.charAt(i);
	}
	
	System.out.println(str2);
}
}
