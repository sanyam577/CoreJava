import java.util.Scanner;

public class ChangeCase {

	public static void main(String[] args) {
		// TO upper case
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a string in lower case");
		String str1 = scan.nextLine();
		String str2 = "";
		
		for(int i= 0; i<str1.length(); i++) {
			str2 = str2 + (char)(str1.charAt(i)-32);
		}
		System.out.println("here is our string in upper case "+ str2);
		
		
		
		
		//to lower case
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a string in UPPER case");
		String str3 = input.nextLine();
		String str4 = "";
		
		for(int i= 0; i<str3.length(); i++) {
			str4 = str4 + (char)(str3.charAt(i)+32);
		}
		System.out.println("here is our string in upper case "+ str4);


	}

}
