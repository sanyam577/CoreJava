import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/*
public class Maps1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     HashMap hs = new HashMap();
     hs.put(10, "Sachin"); //in maps this is known as entry
 	 hs.put(7, "MSD");
	 hs.put(18, "Kohli");
	
	System.out.println(hs); //output will not in order of insertion
	 
	//To achieve output in order of insertion we use linkedhashmap
	
	LinkedHashMap lhm = new LinkedHashMap();
	lhm.put(10, "Sachin");
	lhm.put(7, "Dhoni");
	lhm.put(18, "Kholi");
	System.out.println(lhm); //output will be in order of insertion
     
	}

}
*/










//Accessing values present in map
public class Maps1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     HashMap hs = new HashMap();
     hs.put(10, "Sachin"); //in maps this is known as entry and is known as key-value pair
 	 hs.put(7, "MSD");
	 hs.put(18, "Kohli");
	 
	 System.out.println(hs.get(7)); //it will give you the value at key 7
	 System.out.println("************************");
	 System.out.println("************************");
	 
	 
	 
	 //how to access values
     Collection c= hs.values(); //.values method returns in collection
     Iterator itr1 = c.iterator();
     while(itr1.hasNext()) {
    	String o = (String)itr1.next();
    	 System.out.println("Value : "+o);
    	 //System.out.println(itr1.next());
     }
	 System.out.println("************************");
	 System.out.println("************************");
	 
	 
	 
     //how to access key
      Set s = hs.keySet(); //.keySet method will return Set that why we are recieving it in set
      Iterator itr2 = s.iterator();
      while(itr2.hasNext()) {
    	 // System.out.println(itr2.next());
    	  Integer i = (Integer) itr2.next();
    	  System.out.println("Key : "+i);
      }
      System.out.println("************************");
      System.out.println("************************");
      
      
      
      //how to access whole entry or both key and value
      Set S = hs.entrySet();
      Iterator itr3 = S.iterator();
      while(itr3.hasNext()) {
    	  //System.out.println(itr3.next());
          Map.Entry data = (Entry) itr3.next();  
          System.out.println(data.getKey()+" : "+ data.getValue()+" : ");
      }
	 
	}
}















