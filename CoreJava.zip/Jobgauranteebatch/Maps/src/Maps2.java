import java.util.*;
import java.util.Map.Entry;


class Student1{
  private int age;
  private String name;
  private int marks;
  public Student1(int age, String name, int marks) {
	  this.age = age;
	  this.name= name;
	  this.marks = marks;
  }
public int getAge() {
	return age;
}
public String getName() {
	return name;
}
public int getMarks() {
	return marks;
}

@Override
public String toString() {
	return name+ " " + age +" "+ marks+" ";
}
   
}

public class Maps2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Student1 s1 = new Student1(22, "Yashu", 95);
     Student1 s2 = new Student1(23, "Tanya", 90);
     Student1 s3 = new Student1(24, "Priya", 91);
     
     HashMap h = new HashMap();
     h.put(1, s1);
     h.put(2, s2);
     h.put(3, s3);
     System.out.println(h);
     
     
     System.out.println("***************************");
     System.out.println("***************************");
     Collection c = h.values();
     Iterator itr1 = c.iterator();
     while(itr1.hasNext()) {
    	 System.out.println("value of student : "+ itr1.next());
   
     }
     
     
     System.out.println("***************************");
     System.out.println("***************************");
     Set s = h.keySet();
     Iterator itr2 = s.iterator();
     while(itr2.hasNext()) {
    	 Integer i = (Integer) itr2.next();
    	 System.out.println("Key : "+ i);
     }
     
     
     System.out.println("***************************");
     System.out.println("***************************");
     
     Set S1 = h.entrySet();
     Iterator itr3 = S1.iterator();
     while(itr3.hasNext()) {
    	 Map.Entry data =  (Entry) itr3.next();
    	 System.out.println(data.getKey()+" "+ data.getValue()+" ");
     }
     
     
     
      
	}

}
