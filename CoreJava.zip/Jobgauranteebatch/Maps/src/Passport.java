
import java.util.*;
import java.util.Map.Entry;
class information{
	private String name;
	private int age;
	private String city;
	private String fatherName;
	
	public information(String name, int age, String city, String faterName) {
		this.name= name;
		this.age=age;
		this.city = city;
		this.fatherName= name;	
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getCity() {
		return city;
	}

	public String getFatherName() {
		return fatherName;
	}
	@Override
	public String toString() {
		return name+" "+ age +" " + city +" "+ fatherName +" ";
	}
      
	
	
}
public class Passport {

	public static void main(String[] args) {
	
		information info1 = new information("raju", 22, "basti", "Ram");
		information info2 = new information("roni", 23, "lucknow", "shiv");
		information info3 = new information("ramya", 21, "Vizak", "Manju");
		
		HashMap hm = new HashMap();
		hm.put(1, info1);
		hm.put(2, info2);
		hm.put(3, info3);
		System.out.println(hm);
		
		//access 
		Set s = hm.entrySet();
		Iterator itr = s.iterator();
		while(itr.hasNext()) {
			Map.Entry data = (Entry) itr.next();
			System.out.println(data.getKey()+" "+ data.getValue()+" ");
		}
		
		
	}

}






