/*
class MyThread extends Thread{ //Thread is a inbuilt class
	
	public void run() { //run is a method inside Thread means run() method is predefined 
         for(int i=1; i<10; i++) { //this is the first task
	       System.out.println("Child Thread");
         }
    }
}
public class MultiT1 {

	public static void main(String[] args) {
		MyThread mt = new MyThread();
		mt.start(); // here we use .start() method to call run() method, when start() method is called from this point we have two threads available 
		                                           //one is main thread and another is user defined thread
		for(int i=1; i<10; i++) {                  // Thread scheduler will decide which thread should go for execution
			System.out.println("Main Thread");     //Maximum of the time thread scheduler give first chance to main method thread for execution then user defined thread 
		}

	}

}

*/


/*
class MyThread extends Thread{ //Thread is a inbuilt class
	
	public void run() { //run is a method inside Thread means run() method is predefined 
         for(int i=1; i<10; i++) { //this is the first task
	       System.out.println("Child Thread");
         }
    }
}
public class MultiT1 {

	public static void main(String[] args) {
		MyThread mt = new MyThread();
		mt.run(); //if we directly call run() method there will be single thread  
		                                           
		for(int i=1; i<10; i++) {                  
			System.out.println("Main Thread");      
		}

	}

}
*/



class MyThread extends Thread{ 
	
	public void run() { //run is a method inside Thread means run() method is predefined and is called using .start()
         System.out.println("Main run method ");
         run(5); // we can call another run(int i) method from this run method 
    }
	public void run(int i) {
		System.out.println("Duplicate run method");
        
    }
	
}
	
public class MultiT1 {

	public static void main(String[] args) {
		MyThread mt = new MyThread();
		mt.start(); //here we are calling run() method which don't have any arguments
		// mt.run(7); //we can call that run(int i) method from here too
		                                           
		       
		System.out.println("Main Thread");  

	}

}



