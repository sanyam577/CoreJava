/*
class MyThread1 extends Thread{
	
}

public class getThreadNameMultiT4 {

	public static void main(String[] args) {
		String name = Thread.currentThread().getName();//this is used to get name of thread of current method
		System.out.println("main is exicuted by" + name);

	}

}
*/

/*
class MyThread1 extends Thread{
	
}

public class getThreadNameMultiT4 {

	public static void main(String[] args) {
		String name = Thread.currentThread().getName();//this is used to get name of thread of current method
		System.out.println("main is exicuted by " + name);
          
		MyThread1 t = new MyThread1();
		System.out.println(t.getName()); //default name of user defined thread is Thread-0 
	}

}
*/


/*
class MyThread1 extends Thread{
	@Override
	public void run() {
		String name = Thread.currentThread().getName(); // this will tell the default name of current running thread :Thread-0
		System.out.println("run() is executed by "+ name);  
	}
	
}
public class getThreadNameMultiT4 {

	public static void main(String[] args) {
		String name = Thread.currentThread().getName();//this is used to get name of thread of current method
		System.out.println("main is exicuted by " + name);
          
		MyThread1 t = new MyThread1();
		t.start();
	}

}
*/
/*
// We can change the name of main thread and user defined thread by using getter and setter
class MyThread1 extends Thread{
	@Override
	public void run() {
		String name = Thread.currentThread().getName(); // this will tell the default name of current running thread :Thread-0
		System.out.println("run() is executed by "+ name);  
		
	}
	
}
public class getThreadNameMultiT4 {

	public static void main(String[] args) {
		String name = Thread.currentThread().getName();//this is used to get name of thread of current method
		System.out.println("main() is exicuted by " + name);
          
		MyThread1 t = new MyThread1();
		t.start();
		
		Thread.currentThread().setName("Yashu Thread");
		System.out.println("Name of main thread is changed to "+ Thread.currentThread().getName());
		
	}

}

*/

class MyThread1 extends Thread{
	@Override
	public void run() {
		Thread.currentThread().setName("Run Thread");
		System.out.println("Name of main thread is changed to "+ Thread.currentThread().getName());  
		
	}
	
}
public class getThreadNameMultiT4 {

	public static void main(String[] args) {
		String name = Thread.currentThread().getName();//this is used to get name of thread of current method
		System.out.println("main() is exicuted by " + name);
          
		MyThread1 t = new MyThread1();
		t.start();
		
		Thread.currentThread().setName("Yashu Thread");
		System.out.println("Name of main thread is changed to "+ Thread.currentThread().getName());
		
	}

}
















