//internally TreeSet uses this method to compare data "compareTo()"
// obj1.compareTo(obj2) 1. if obj1>obj2 return +ve value
//                       2. if obj1<obj2 return -ve value
 //                      3. if obj1=obj2 return 0


public class CC3 {

	public static void main(String[] args) {
		
		System.out.println("A".compareTo("Z"));//-ve
		System.out.println("Z".compareTo("K")); //+ve
		System.out.println("Z".compareTo("Z"));// 0
		System.out.println("Z".compareTo(null)); //java.lang.NullPointerExcepetion
	}

}
