import java.util.*;
//write a program to insert StringBuffer objects into the TreeSet where Sorting Order is Alphabetical Order
/*
class  MyComparator2 implements Comparator{
	@Override 
	public int compare(Object obj1, Object obj2) {
		String s1 =obj1.toString();
		String s2 =obj2.toString();
		
		//natural sorting order
		return s1.compareTo(s2);
	}
}

public class CC6 {

	public static void main(String[] args) {
		
		TreeSet ts = new TreeSet(new MyComparator2());
		ts.add(new StringBuffer("Sachin"));
		ts.add(new StringBuffer("Pointing"));
		ts.add(new StringBuffer("Gayle"));
		ts.add(new StringBuffer("Develliers"));
		ts.add(new StringBuffer("Jaysuriya"));
   System.out.println(ts); 
   
   
   //Ascending order :- [Develliers, Gayle, Jaysuriya, Pointing, Sachin]	 	
		

	}

}
*/



//write a program to insert String and StringBuffer objects into the TreeSet where Sorting Order in increasing length order
//if two object have same length then consider their  Alphabetical Order

class  MyComparator2 implements Comparator{
	@Override 
	public int compare(Object obj1, Object obj2) {
		String s1 =obj1.toString();
		String s2 =obj2.toString();
		
		//natural sorting order
		if(s1.length()<s2.length())
		{
			return -1;
		}
		else if(s1.length()>s2.length()){
			return +1;
		}
		else {
			return s1.compareTo(s2);
		}
	}
}

public class CC6 {

	public static void main(String[] args) {
		
		TreeSet ts = new TreeSet(new MyComparator2());
		ts.add("A");
		ts.add(new StringBuffer("ABC"));
		ts.add(new StringBuffer("AA"));
		ts.add("XX");
		ts.add("ABCE");
		ts.add("A");
   System.out.println(ts); 
	}

}















