import java.util.*;
//Comparable interface :- sorting is done naturally (using compareTo() method)
//But sometime we need sorting according to the condition the we go for "Comparator interface"
//Comparator interface :- customized sorting (present in java.util Package)
//there are two methods compare() , equals()
//Implementation of compare() method is mandatory 

//here in this program we are going to sort in descending order 


/*
class MyComparator implements Comparator{
	@Override
	public int compare(Object obj1, Object obj2) {
		System.out.println("compare() method is called");
		//logic
		Integer i1 = (Integer)obj1;
		Integer i2 = (Integer)obj2;
		
		if(i1<i2)
			return +1;
		else if(i1>i2)
			return -1;
		else return 0;
	}
}

public class CC4 {

	public static void main(String[] args) {
		
		TreeSet ts = new TreeSet(new MyComparator()); //creating object 
		ts.add(10); 
		ts.add(0);    //compare(0,10) = -ve but because of logic present above it will become +ve (reverse)
		ts.add(15);    //compare(15,10) = +ve but because of logic present above it will become -ve (reverse)
		ts.add(5);      //compare(5,10)= -ve then +ve      ,    compare(5,0) = +ve then -ve
		ts.add(20);    //compare(20,10) = +ve then -ve     ,    compare(20,15)= +ve then -ve
		ts.add(20);    //compare(20,10)= +ve then -ve ,   compare(20,15) =+ve then -ve ,   compare(20,20) = 0
	System.out.println(ts);	
		   
	
	//+ve right side in treeset diagram
	//-ve left side in treeset diagram
	// 0 means no change
	

	}

}
*/




//when object is implementing comparable interface then we can use compareTo method in logic
class MyComparator implements Comparator{
	@Override
	public int compare(Object obj1, Object obj2) {
		System.out.println("compare() method is called");
		//logic
		Integer i1 = (Integer)obj1;
		Integer i2 = (Integer)obj2;
		
	        return i1.compareTo(i2);      //[0, 5, 10, 15, 20] ascending order
	    //  return -i1.compareTo(i2);     //[20, 15, 10, 5, 0] descending order
	   //  return i2.compareTo(i1);     //[20, 15, 10, 5, 0] descending order
	  //   return -i2.compareTo(i1);      //[0, 5, 10, 15, 20] ascending order
	 //	   return +1;                    //[10, 0, 15, 5, 20, 20] in order of insertion
	//	   return-1;                     // [20, 20, 5, 15, 0, 10] reverse of insertion order
	//	   return 0;                     // [10] only first value
	      
	      
	}
}

public class CC4 {

	public static void main(String[] args) {
		
		TreeSet ts = new TreeSet(new MyComparator()); // 
		ts.add(10); //if our object (10 is Integer is object) is implementing comparable interface the we can use compareTo method
		ts.add(0);    
		ts.add(15);    
		ts.add(5);     
		ts.add(20);    
		ts.add(20);    
	System.out.println(ts);	
		   
		

	}

}










