import java.util.TreeSet;

//the object should compulsorily implements an interface an interface called "Comparable interface ".
//if we fail to do so , it would result in "ClassCastException".
public class CC2 {
	public static void main(String [] args) {
		TreeSet ts = new TreeSet();
		ts.add(new StringBuffer("A"));
		ts.add(new StringBuffer("Z"));
		ts.add(new StringBuffer("L"));
		ts.add(new StringBuffer("B"));
		
		System.out.println(ts); //"ClassCastException"
		
	}

}

//all wrapper classes and string class has implemented "Comparable" interface
//StringBuffer class has not implemented Comparable interface, so the above program would result in "ClassCastException".