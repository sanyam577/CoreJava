import java.util.*;
//write a program to insert string objects into the TreeSet where the Sorting Order is of Reverse of Alphabetical Order
class MyComparator1 implements Comparator
{
     @Override
     public int compare(Object obj1, Object obj2) {
    	 String s1 =(String)obj1;
    	 String s2 = obj2.toString();
    	 
    	 //reverse of natural order 
    	 return -s1.compareTo(s2);
     }
}
public class CC5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  
		TreeSet ts = new TreeSet(new MyComparator1());
		ts.add("Sachin");
		ts.add("Ponting");
		ts.add("Gayle");
		ts.add("Develliers");
		ts.add("Jaysuriya");
	System.out.println(ts);	
	}

}

//  Output :- [Sachin, Ponting, Jaysuriya, Gayle, Develliers]  descending order