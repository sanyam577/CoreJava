import java.util.*;
//TreeSet only homogeneous type of data

public class CC1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TreeSet ts = new TreeSet();
		ts.add("A");
		ts.add("Z");
		ts.add("L");
		ts.add("B");
	//	ts.add(null); java.lang.NullPointerException
   //   ts.add(5);    java.lang.ClassCastException: class java.lang.String cannot be cast to class java.lang.Integer 
		
		System.out.println(ts);

	}

}
//for string and number default sorting order is ascending order  :=>  [A, B, L, Z]