class MyThread2 extends Thread{
	
	@Override
	public void run() {
		
		for(int i=0; i<10; i++) {  
			for(int j=0; j<10; j++) {
			if(i==0||j==0||i==9||j==9) {
				System.out.print("*");
			}
			else {
				System.out.print("_");
			}
			try {
				Thread.sleep(1000);
			}
			catch(InterruptedException e) {
				
			}
			}
			System.out.println();
			
		}
	}
}

public class JoinMultiT3 {
    
	public static void main(String[] args) throws InterruptedException {
        MyThread2 t = new MyThread2();
		t.start();
		t.join(); // sam will wait for yashu thread until it will not finish execution
		for(int i=1; i<=5; i++) {
		   System.out.println("Sam Thread");
		}
		
	}

}




