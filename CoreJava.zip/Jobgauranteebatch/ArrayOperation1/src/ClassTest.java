import java.util.Scanner;

public class ClassTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int [] arr =new int[6];
		for(int i=0; i<arr.length;i++) {
			System.out.println("Enter element of index "+i);
			arr[i]= scan.nextInt();
		}
		
		System.out.println("Here is your array");
		for(int i=0; i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		System.out.println("Enter the key");
		
		int key = scan.nextInt();
		boolean flag=false;
		
		for(int i=0; i<arr.length; i++) {
			if(key==arr[i]) {
				System.out.println("Key found at index "+i);
				flag=true;
				break;
			}
		}
		if(flag==false) {
			System.out.println("key not found");
		}
		
		

	}

}
