abstract class Computer{
	abstract public void disp();
}

/*   
 * class Laptop extends Computer{
      public void disp()//
          {
        System.out.println("This method is present in abstract class");
	}

}             //we can use abstract method like this but ...
*/


public class InnerClass4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Computer obj = new Computer() {
			
			public void disp() {
				System.out.println("Bro this is anonymous class ");
			}
			
		};
		obj.disp();
		
        Computer obj1 = new Computer() { 
			
			public void disp() { //we can create many anonymous class 
				System.out.println("Bro this is anonymous class ");
			}
			
		};
		obj1.disp();

	}

}
