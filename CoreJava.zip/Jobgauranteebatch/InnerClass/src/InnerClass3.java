class A1{
	
	
	
	public void display() {
		System.out.println("Hi Thanos is side");
		
		 class B1 { //we can create inner class inside a method but we can use it within this method only
            
           public void config() 
          {	
            System.out.println("Inner class");

          }
       }
				
	}
	
       

}

public class InnerClass3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A1 dis = new A1();
		dis.display();
		
		
		
		    
	}

}
