class AA{
	
	public void display() {
		System.out.println("Hi Thanos is side");
		
	}
	
        static class B { //This is our inner class (class inside another class)
		                  //iF WE MAKE INNER CLASS STATIC THEN WE CAN CALL IT BY USING IR'S PARENT CLASS (AA.B)
		    public void config() 
		   {	
		     System.out.println("Inner class");
		
	     	}
         }

}





public class InnerClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AA dis = new AA();
		dis.display();
		
		
		//method 1
		AA.B obj1; //we are taking refrence of class AA which shows class B belongs to class A        //B is Static inner class  // here we are creating our refrence variable in line30 and defining our object in next line 
		obj1 =new AA.B();
		obj1.config();      // now we can call our method after declaring our inner class as inner
		
		//method 2 (REMOVE Static keyword from INNER CLASS B)
		//AA.B OBJ1;
		//OBJ1 = dis.new B(); // we can use parent object (dis)
		//OBJ1.config();		

	}

}
