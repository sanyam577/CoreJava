
public class  ForEachLoop {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int[][] ar= {{10,20,30,40},{50,30,87,90}};
		
		for(int nv[]:ar) {
			for(int elem:nv) {
				System.out.print(elem+" ");
			}
			System.out.println();
		}
	}

}
