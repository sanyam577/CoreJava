
public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ar []= {52,45,87,78,96,56};
		for(int i=ar.length-1; i>=
				0; i--) {
			System.out.println(ar[i]+" ");
		}

	}

}
