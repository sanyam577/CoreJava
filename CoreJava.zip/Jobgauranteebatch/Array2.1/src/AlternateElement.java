
public class AlternateElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] ar= {20,30,57,96,78,54,62};
		
		for(int i=0; i<ar.length; i++) {
			System.out.println(ar[i] + " ");
			i++;
		}

	}

}
