
public class MaxAndMin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] arr= {23,32,45,67,56,89,90};
		int max = arr[0];
		for(int i=0; i<arr.length; i++) {
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		System.out.println(max);
		
		
		int min = arr[0];
		for(int i=0; i<arr.length; i++) {
			if(arr[i]<min) {
				min=arr[i];
			}
		}
		System.out.println(min);


	}

}
