
public class SumTotal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] ar = {25,45,63,48};
		int sum=0;
		for(int i=0; i<ar.length; i++) {
			sum=sum + ar[i];
			
		}
		System.out.print(sum);

	}

}
