//synchronized block
/*
class Display{
	
	public void wish(String name) {
		;;;; // 1 lakh lines of code
		synchronized(this){
		for(int i=0; i<=10; i++) {
			System.out.print("Good morning: ");
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				
			}
			System.out.println(name);
		}
	}
		;;;;; // thousands lines of code
}

}

class MyThread extends Thread{
	
	Display d;
	String name;
	
	MyThread(Display d, String name){
		this.d = d;
		this.name = name;
	}
	
	
	@Override
	public void run() {
		d.wish(name);
	}
}


public class SynchronizedBlock {

	public static void main(String[] args) {
       Display d= new Display();
		
		
		MyThread t1 = new MyThread(d, "ram");
		t1.start();
		
		MyThread t2 = new MyThread(d, "sita");
		t2.start();
		
		

	}

} */


/*
//code outside synchronized block will run freely no impact of lock 
class Display{
	
	public void wish(String name) {
		;;;; // 1 lakh lines of code
	   System.out.println("This thread got a chance "+ Thread.currentThread().getName());
		
		synchronized(this){
		for(int i=0; i<=5; i++) {
			System.out.print("Good morning: ");
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				
			}
			System.out.println(name);
		}
	}
		
		;;;;; // thousands lines of code
}

}

class MyThread extends Thread{
	
	Display d;
	String name;
	
	MyThread(Display d, String name){
		this.d = d;
		this.name = name;
	}
	
	
	@Override
	public void run() {
		d.wish(name);
	}
}


public class SynchronizedBlock {

	public static void main(String[] args) {
       Display d= new Display();
		
		
		MyThread t1 = new MyThread(d, "ram");
		t1.start();
		
		MyThread t2 = new MyThread(d, "sita");
		t2.start();
		
		
		t1.setName("Ram Thread");
		t2.setName("sita thread");
		

	}

}
*/




/*
//code inside synchronized block will run with thread under block lock 
class Display{
	
	public void wish(String name) {
		;;;; // 1 lakh lines of code
	  
		synchronized(this){
		System.out.println("This thread got a chance:: "+ Thread.currentThread().getName());
		for(int i=0; i<=5; i++) {
			System.out.print("Good morning: ");
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				
			}
			System.out.println(name);
		}
	}
		System.out.println("This thread releasing the lock:: "+ Thread.currentThread().getName());
		;;;;; // thousands lines of code
}

}

class MyThread extends Thread{
	
	Display d;
	String name;
	
	MyThread(Display d, String name){
		this.d = d;
		this.name = name;
	}
	
	
	@Override
	public void run() {
		d.wish(name);
	}
}


public class SynchronizedBlock {

	public static void main(String[] args) {
     Display d= new Display();
		
		
		MyThread t1 = new MyThread(d, "ram");
		t1.start();
		
		MyThread t2 = new MyThread(d, "sita");
		t2.start();
		
		
		t1.setName("Ram Thread");
		t2.setName("sita thread");
		

	}

}
*/



/*
//if we have two objects both thread will run in parallel
class Display{
	
	public void wish(String name) {
		;;;; // 1 lakh lines of code
	  
		synchronized(this){ //block level lock
		System.out.println("This thread got a chance:: "+ Thread.currentThread().getName());
		for(int i=0; i<=5; i++) {
			System.out.print("Good morning: ");
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				
			}
			System.out.println(name);
		}
	}
		System.out.println("This thread releasing the lock:: "+ Thread.currentThread().getName());
		;;;;; // thousands lines of code
}

}

class MyThread extends Thread{
	
	Display d;
	String name;
	
	MyThread(Display d, String name){
		this.d = d;
		this.name = name;
	}
	
	
	@Override
	public void run() {
		d.wish(name);
	}
}


public class SynchronizedBlock {

	public static void main(String[] args) {
     Display d1= new Display();
     Display d2= new Display();	
		
		MyThread t1 = new MyThread(d1, "ram");
		t1.start();
		
		MyThread t2 = new MyThread(d2, "sita");
		t2.start();
		
		
		t1.setName("Ram Thread");
		t2.setName("sita thread");
		

	}

}
*/




//if we have two objects both thread will run in parallel
//and we applied class level lock
class Display{
	
	public void wish(String name) {
		;;;; // 1 lakh lines of code
	  
		synchronized(Display.class){ //class level lock (even though we have two separate objects because of class lock one by one they will the chance)
		System.out.println("This thread got a chance:: "+ Thread.currentThread().getName());
		for(int i=0; i<=5; i++) {
			System.out.print("Good morning: ");
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				
			}
			System.out.println(name);
		}
	}
		System.out.println("This thread releasing the lock:: "+ Thread.currentThread().getName());
		;;;;; // thousands lines of code
}

}

class MyThread extends Thread{
	
	Display d;
	String name;
	
	MyThread(Display d, String name){
		this.d = d;
		this.name = name;
	}
	
	
	@Override
	public void run() {
		d.wish(name);
	}
}


public class SynchronizedBlock {

	public static void main(String[] args) {
     Display d1= new Display();
     Display d2= new Display();	
		
		MyThread t1 = new MyThread(d1, "ram");
		t1.start();
		
		MyThread t2 = new MyThread(d2, "sita");
		t2.start();
		
		
		t1.setName("Ram Thread");
		t2.setName("sita thread");
		

	}

}












