/*
class ThreadB extends Thread{
	int total =0;
	@Override
	public void run(){
		
		synchronized(this) { //after getting lock from main method this child method start execution step2
			System.out.println("Child thread started the calculation"); // step 2
			for(int i=0; i<=100; i++) {
				total+=i;
			}
			System.out.println("Child thread giving notification call"); //step 3 //after execution child method will notify 
			this.notify();   //main method and lock to it then main method go to final waiting area and then 
		}
		
	}
}


public class NotifyMain {

	public static void main(String[] args) throws Exception
	{
		ThreadB b = new ThreadB();
		b.start();
		//from here two thread  will created main(5), child(5)
		
		synchronized(b) {
			System.out.println("main thread calling wait() method");//step 1 , when main thread see this wait() method
			b.wait();     //it will go in waiting area and give lock to child thread so that child method start execution 
			System.out.println("main thread got notification call");// step 4 start execution again
			System.out.println(b.total);
			
		}

	}

}
*/



/*
class ThreadB extends Thread{
	int total =0;
	@Override
	public void run(){
		
		synchronized(this) { //after getting lock from main method this child method start execution step2
			System.out.println("Child thread started the calculation"); // step 2
			for(int i=0; i<=100; i++) {
				total+=i;
			}
			System.out.println("Child thread giving notification call"); //step 3 //after execution child method will notify 
			this.notify();   //main method and lock to it then main method go to final waiting area and then 
		}
		
	}
}


public class NotifyMain {

	public static void main(String[] args) throws Exception
	{
		ThreadB b = new ThreadB();
		b.start();
		//from here two thread  will created main(5), child(5)
		 //what if we make main thread to sleep
		Thread.sleep(3000); //we the main thread is sleeping thread scheduler will give chance to child thread to execute
		                    //and child thread will complete it's execution and send notification to main thread 
		                    //but main thread is sleeping then child thread will go to dead state      
		                  //when main thread wake up and execute wait() method there will be no on to receive the lock
		                 //so the main method will go to infinite waiting state "this is known as dead lock"
		synchronized(b) {
			System.out.println("main thread calling wait() method");//step 1 , when main thread see this wait() method
			b.wait();     //it will go in waiting area and give lock to child thread so that child method start execution 
			System.out.println("main thread got notification call");// step 4 start execution again
			System.out.println(b.total);
			
		}

	}

}
*/

class ThreadB extends Thread{
	int total =0;
	@Override
	public void run(){
		
		synchronized(this) { //after getting lock from main method this child method start execution step2
			System.out.println("Child thread started the calculation"); // step 2
			for(int i=0; i<=100; i++) {
				total+=i;
			}
			try {
				Thread.sleep(3000);
			}
			catch(Exception e) {
				
			}
			System.out.println("Child thread giving notification call"); //step 3 //after execution child method will notify 
			this.notify();   //main method and lock to it then main method go to final waiting area and then 
		}
		
	}
}


public class NotifyMain {

	public static void main(String[] args) throws Exception
	{
		ThreadB b = new ThreadB();
		b.start();
		//from here two thread  will created main(5), child(5)
		
		synchronized(b) {
			System.out.println("main thread calling wait() method");//step 1 , when main thread see this wait() method
			b.wait();     //it will go in waiting area and give lock to child thread so that child method start execution 
			System.out.println("main thread got notification call");// step 4 start execution again
			System.out.println(b.total);
			
		}

	}

}





















