import java.util.Scanner;

class Gusser22{
	int guessNum;
	
	int guessNum(){
	Scanner	scan=new Scanner(System.in);
	System.out.println("Hello Guesser Enter your name");
	String username = scan.next();
	System.out.println(username);
	
	if(username.equalsIgnoreCase(username)) {
		System.out.println("Valid user for this game");
	}
	else {
		System.out.println("Invalid user");
	}
	
	System.out.println();
	System.out.println("Enter password to login");
	String password = scan.next();
	
	if(password.equals(password)) {
		System.out.println("Valid password");
	}
	else {
		System.out.println("Wrong password");
	}
	
	System.out.println();
	
	System.out.println("Gusser kindly guess a number ");
	guessNum= scan.nextInt();
	return guessNum;
	}
}


class Player22{
	int guessNum;
	
	int guessNum(){
	Scanner	scan=new Scanner(System.in);
	
	System.out.println("Hello Player Enter your name");
	String username = scan.next();
	System.out.println(username);
	
	if(username.equalsIgnoreCase(username)) {
		System.out.println("Valid user for this game");
	}
	else {
		System.out.println("Invalid user");
	}
	
	System.out.println();
	System.out.println("Enter password to login");
	String password = scan.next();
	
	if(password.equals(password)) {
		System.out.println("Valid password");
	}
	else {
		System.out.println("Wrong password");
	}
	
	System.out.println("Player kindly guess a number ");
	guessNum=scan.nextInt();
	return guessNum;
	}
}

class Umpire22{
	int numOfGusser;
	int numOfPlayer1;
	int numOfPlayer2;
	int numOfPlayer3;
	
	
	
	void collectNumFromGusser(){
	Gusser22	g =new Gusser22();
	numOfGusser =g.guessNum();
	}
	void collectNumFromPlayer() {
		Player22 p1= new Player22();
		Player22 p2= new Player22();
		Player22 p3 = new Player22();
		
		numOfPlayer1= p1.guessNum();
		numOfPlayer2= p2.guessNum();
		numOfPlayer3= p3.guessNum();	
		
	}
	
	void compare() {
		if(numOfGusser==numOfPlayer1) {
			
			if(numOfGusser==numOfPlayer2 && numOfGusser==numOfPlayer3) {
				System.out.println("All won the game");
			}
			else if(numOfGusser==numOfPlayer2) {
				System.out.println("Player 1 and 2 won the game");
			}
			else if(numOfGusser==numOfPlayer3) {
				System.out.println("Player 1 and 3 won the game");
			}
			else {
				System.out.println("Player 1 won the game");
			}
			
		}
		else if(numOfGusser==numOfPlayer2) {
			if(numOfGusser==numOfPlayer3) {
				System.out.println("Player 2 and 3 won the game");
			}
			else {
				System.out.println("Player 2 won the game");
			}
		}
		else if(numOfGusser==numOfPlayer3) {
			System.out.println("Player 3 won");
		}
		else {
			System.out.println("No one won the game");
		}
		
		
	}
}


public class New {
public static void main(String [] args) {
      Umpire22	u = new Umpire22();
      u.collectNumFromGusser();
      u.collectNumFromPlayer();
      u.compare();

	
}

}