import java.util.*;

class Gusser{
	int guessNum;
	
	int guessNum(){
	Scanner	scan=new Scanner(System.in);
	System.out.println("Gusser kindly guess a number ");
	guessNum= scan.nextInt();
	return guessNum;
	}
}


class Player{
	int guessNum;
	
	int guessNum(){
	Scanner	scan=new Scanner(System.in);
	System.out.println("Player kindly guess a number ");
	guessNum=scan.nextInt();
	return guessNum;
	}
}

class Umpire{
	int numOfGusser;
	int numOfPlayer1;
	int numOfPlayer2;
	int numOfPlayer3;
	
	
	
	void collectNumFromGusser(){
	Gusser	g =new Gusser();
	numOfGusser =g.guessNum();
	}
	void collectNumFromPlayer() {
		Player p1= new Player();
		Player p2= new Player();
		Player p3 = new Player();
		
		numOfPlayer1= p1.guessNum();
		numOfPlayer2= p2.guessNum();
		numOfPlayer3= p3.guessNum();	
		
	}
	
	void compare() {
		if(numOfGusser==numOfPlayer1) {
			
			if(numOfGusser==numOfPlayer2 && numOfGusser==numOfPlayer3) {
				System.out.println("All won the game");
			}
			else if(numOfGusser==numOfPlayer2) {
				System.out.println("Player1 and 2 won the game");
			}
			else if(numOfGusser==numOfPlayer3) {
				System.out.println("Player 1 and 3 won the game");
			}
			else {
				System.out.println("Player 1 won the game");
			}
			
		}
		else if(numOfGusser==numOfPlayer2) {
			if(numOfGusser==numOfPlayer3) {
				System.out.println("Player 2 and 3 won the game");
			}
			else {
				System.out.println("Player 2 won the game");
			}
		}
		else if(numOfGusser==numOfPlayer3) {
			System.out.println("Player 3 won");
		}
		else {
			System.out.println("No one won the game");
		}
		
		
	}
}




public class LaunchGame {
public static void main(String [] args) {
      Umpire	u = new Umpire();
      u.collectNumFromGusser();
      u.collectNumFromPlayer();
      u.compare();

	
}

}
