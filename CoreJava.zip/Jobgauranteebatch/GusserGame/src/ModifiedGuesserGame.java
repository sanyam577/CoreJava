import java.util.Scanner;

class Gusser{
	int guessNum;
	
	int guessNum(){
	Scanner	scan=new Scanner(System.in);
	System.out.println("Gusser kindly guess a number ");
	guessNum= scan.nextInt();
	if(guessNum>0 && guessNum<10) {
	return guessNum;}
	else {
		System.out.println("Error :- Enter number between 0 to 10 ");
		return 0;
			
	}
	}
}


class Player{
	int guessNum1;
	int guessNum2;
	int guessNum3;
	
	int guessNum1(){
	Scanner	scan=new Scanner(System.in);
	System.out.println("Player 1 kindly guess a number ");
	guessNum1=scan.nextInt();
	return guessNum1;
	}
	
	int guessNum2(){
		Scanner	scan=new Scanner(System.in);
		System.out.println("Player2 kindly guess a number ");
		guessNum2=scan.nextInt();
		return guessNum2;
		}
	
	int guessNum3(){
		Scanner	scan=new Scanner(System.in);
		System.out.println("Player3 kindly guess a number ");
		guessNum3=scan.nextInt();
		return guessNum3;
		}
}

class Umpire{
	int numOfGusser;
	int numOfPlayer1;
	int numOfPlayer2;
	int numOfPlayer3;
	
	
	
	void collectNumFromGusser(){
	Gusser	g =new Gusser();
	numOfGusser =g.guessNum();
	}
	void collectNumFromPlayer() {
		Player p1= new Player();
		Player p2= new Player();
		Player p3 = new Player();
		
		numOfPlayer1= p1.guessNum1();
		numOfPlayer2= p2.guessNum2();
		numOfPlayer3= p3.guessNum3();	
		
	}
	
	void compare() {
		if(numOfGusser==numOfPlayer1) {
			
			if(numOfGusser==numOfPlayer2 && numOfGusser==numOfPlayer3) {
				System.out.println("All won the game");
			}
			else if(numOfGusser==numOfPlayer2) {
				System.out.println("Player1 and 2 won the game");
			}
			else if(numOfGusser==numOfPlayer3) {
				System.out.println("Player 1 and 3 won the game");
			}
			else {
				System.out.println("Player 1 won the game");
			}
			
		}
		else if(numOfGusser==numOfPlayer2) {
			if(numOfGusser==numOfPlayer3) {
				System.out.println("Player 2 and 3 won the game");
			}
			else {
				System.out.println("Player 2 won the game");
			}
		}
		else if(numOfGusser==numOfPlayer3) {
			System.out.println("Player 3 won");
		}
		else {
			System.out.println("No one won the game");
		}
		
		
	}
}


public class ModifiedGuesserGame {
public static void main(String[] args) {
      Umpire	u = new Umpire();
      u.collectNumFromGusser();
      u.collectNumFromPlayer();
      u.compare();

	
}

}




