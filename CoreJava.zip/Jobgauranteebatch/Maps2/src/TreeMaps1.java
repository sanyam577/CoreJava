import java.util.TreeMap;

public class TreeMaps1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeMap tm = new TreeMap();
		tm.put(10, "Dog");
		tm.put(14, "Cat");
		tm.put(12, "Rat");
		tm.put(9, "Ant");
		System.out.println(tm); //result will be in ascending order
		
	}

}
