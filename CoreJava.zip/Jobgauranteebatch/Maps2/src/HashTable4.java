//Hashtable is Synchronized  
//Hashtable is a legacy class means it's in existence since java 1.0
import java.util.*;

class Ineuron{
	int i;
	public Ineuron(int i) {
		this.i=i;
	}
	public String toString() {
		return i+ "";
	}
}

public class HashTable4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Hashtable hs = new Hashtable();
     hs.put(11, "Sachin");
     hs.put(12, "Ram");
     hs.put(13, "Radha");
     System.out.println(hs);
     
     Hashtable ht = new Hashtable();
     ht.put(new Ineuron(11), "Sam");
     ht.put(new Ineuron(12), "Ram");
     ht.put(new Ineuron(13), "Dev");
     
 	System.out.println(ht);
	
	
 	/// equals();  in HashMap is used to compare content 
 			///==:  in IdentityHashMap is used to compare content
     
	}

}

//Hashtable java1.0
//HashMap java 1.2

//Hashtable - synchronized (Multithreading not possible
//HashMap - non synchronized (Multithreading possible

//Hashtable - Thread safe
//HashMap - not safe

//Hashtable - Low performance
//HashMap - High performance