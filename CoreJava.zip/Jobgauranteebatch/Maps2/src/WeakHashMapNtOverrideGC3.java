import java.util.*;

//HashMap over ride garbage collector
class Employee1{
	private String name;
	private Integer age;
	//setter and getter
	
	@Override
	public String toString() {
		return "Sanyam";
	}
	@Override
	public void finalize() { //this inbuilt method is used to collect garbage 
		System.out.println("Garbage Collector collected the object");
	}
}
public class WeakHashMapNtOverrideGC3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Employee1 em = new Employee1(); //one object created 
         WeakHashMap hm = new WeakHashMap();
         hm.put(em, "Sanyam"); //here we assigned a value to the refrence variable
         
         
         em=null ; //again we reassign null to reference variable em means there is no refrence pointing to employee object
          System.gc();     //here finalize method is getting invoke means GC is dominating
          System.out.println("Last Line: Gc is unable to collect");
         
	}

}
