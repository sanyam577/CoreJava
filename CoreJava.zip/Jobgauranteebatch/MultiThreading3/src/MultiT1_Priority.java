/*
class MyThread extends Thread{
	
	@Override
	public void run() {
		System.out.println("Priority of child thread is "+ Thread.currentThread().getPriority());
		//it will tell the default priority of child thread
	}
}

public class MultiT1_Priority {
    
	public static void main(String[] args) {
	System.out.println("Priority of main thread is "+ Thread.currentThread().getPriority());
	//it will tell the default priority of main thread
		MyThread t = new MyThread();
         t.start();
	}

}
*/


//we can give priority of our own 
//it is ranked based
//range starts from 1 to 10
class MyThread extends Thread{
	
	@Override
	public void run() {
		System.out.println("Priority of child thread is "+ Thread.currentThread().getPriority());
		//it will tell the default priority of child thread
	}
}

public class MultiT1_Priority {
    
	public static void main(String[] args) {
	System.out.println("Priority of main thread is "+ Thread.currentThread().getPriority());
	//it will tell the default priority of main thread
		MyThread t = new MyThread();
		t.setPriority(10); // here we are giving priority by ourself 
         t.start();
	}

}


