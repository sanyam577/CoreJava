class MyThread1 extends Thread{
	
	@Override
	public void run() {
		for(int i=1; i<=5; i++) {
			Thread.yield();  //The yield() basically means that the thread is not doing anything particularly important 
			                       //and if any other threads or processes need to be run, they should run. Otherwise,
			                                 //the current thread will continue to run.
			System.out.println("Child Thread");
		}
	}
}

public class YieldMultiT2 {
    
	public static void main(String[] args) {
        MyThread1 t = new MyThread1();
		t.start();
		for(int i=1; i<=5; i++) {
		   System.out.println("Main Thread");
		}
		
	}

}








