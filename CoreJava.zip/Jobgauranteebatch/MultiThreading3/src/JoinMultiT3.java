

/*
class MyThread2 extends Thread{
	
	@Override
	public void run() {
		
		for(int i=1; i<=5; i++) {  
			System.out.println("Yashu Thread");
		}
	}
}

public class JoinMultiT3 {
    
	public static void main(String[] args) throws InterruptedException {
        MyThread2 t = new MyThread2();
		t.start();
		t.join(); // this will wait for yashu thread (old age sam will wait for yashu till infinity)
		for(int i=1; i<=5; i++) {
		   System.out.println("Sam Thread");
		}
		
	}

}
*/


/*
class MyThread2 extends Thread{
	
	@Override
	public void run() {
		
		for(int i=1; i<=5; i++) {  
			
			System.out.println("Yashu Thread");
			try {
				Thread.sleep(3000);//pause the execution for 3-3 sec and sam thread will wait for yashu thread execution 
			}
			catch(InterruptedException e) {
				
			}
		}
	}
}

public class JoinMultiT3 {
    
	public static void main(String[] args) throws InterruptedException {
        MyThread2 t = new MyThread2();
		t.start();
		t.join(); // sam will wait for yashu thread until it will not finish execution
		for(int i=1; i<=5; i++) {
		   System.out.println("Sam Thread");
		}
		
	}

}

*/

class MyThread2 extends Thread{
	
	@Override
	public void run() {
		
		for(int i=1; i<=5; i++) {  
			
			System.out.println("Yashu Thread");
			try {
				Thread.sleep(3000);
			}
			catch(InterruptedException e) {
				
			}
		}
	}
}

public class JoinMultiT3 {
    
	public static void main(String[] args) throws InterruptedException {
        MyThread2 t = new MyThread2();
		t.start();
		t.join(1000); // this will wait for yashu thread for 1 sec only and then start execution (modern sam don't wait for a long period of time only 1 sec)
		for(int i=1; i<=5; i++) {
		   System.out.println("Sam Thread");
		}
		
	}
}


