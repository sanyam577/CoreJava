package in.ineuron.bean;

//target object
public class Student {
	private String sid;
	private String sname;
	private String saddr;
	
	//HAS-A relationship
	private Course [] course;

	public Student(String sid, String sname, String saddr, Course[] course) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.saddr = saddr;
		this.course = course;
	}
	
	public void getStudentDetails() {
		System.out.println("STUDENT DETAILS ARE:: ");
		System.out.println("ID is "+sid);
		System.out.println("NAME is "+sname);
		System.out.println("ADDR is "+saddr);
		
		System.out.println("COUSE DETAILS ARE:: ");
		for(Course c: course) {
		System.out.println("CID is "+c.cid);
		System.out.println("CNAME is "+c.cname);
		System.out.println("CCOST is "+c.ccost);
		}
		System.out.println("-------------------------");
	}

}
