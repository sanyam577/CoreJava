package in.ineuron.bean;

public class Course {
	String cid;
	String cname;
	int ccost;
	public Course(String cid, String cname, int ccost) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.ccost = ccost;
	}

}
