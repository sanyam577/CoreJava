import java.util.ArrayList;

//generic is limited at compiler level 

public class G3 {

	public static void main(String[] args) {
		
		ArrayList al1 = new ArrayList<Integer>(); //after compilation //ArrayList al1 = new ArrayList();
		al1.add("Ama");
		al1.add("Dhoni");
		
		
		ArrayList al2 = new ArrayList<String>(); //compiler will only check the left most part of this line
		al1.add(5);                      //there is no generic means compiler will consider this line as a non-generic line
		al1.add(10.5);                  //and compile it and remove the right side generic syntax
		al1.add("sachin");                //ArrayList al2 = new ArrayList();
	}

}

//means there is no use of generic syntax at right side alone 