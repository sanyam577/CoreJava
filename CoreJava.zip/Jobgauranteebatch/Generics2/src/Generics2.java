import java.util.ArrayList;

//method overloading is not possible 


public class Generics2 {
	//MethodOverloading
//	public void m1(ArrayList<Integer> a) {}
//	public void m1(ArrayList<String> b) {}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

}


 //1. Compiler will scan the code
//2. Check the argument type
//public void m1(ArrayList<Integer> a) {}
//public void m1(ArrayList<String> b) {}
//3. If generics found in the argument type of method then compiler will remove the generic syntax
//public void m1(ArrayList a) {}
//public void m1(ArrayList b) {}
//4. Compiler will again check the syntax 


//compiler removed generic because there is no use of generic at jvm level