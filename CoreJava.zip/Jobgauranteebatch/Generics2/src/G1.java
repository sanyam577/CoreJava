import java.util.ArrayList;

//Generic method with wild card pattern


public class G1 {

	public static void main(String[] args) {
        
		ArrayList<String> l1=new ArrayList<String>();//valid
		ArrayList<?> l2=new ArrayList<String>();//valid
		 ArrayList<?> l3=new ArrayList<Integer>();//valid
		 ArrayList<? extends Number> l4=new ArrayList<Integer>();//valid parent-child
	//	 ArrayList<? extends Number> l5=new ArrayList<String>();//invalid no relation of parent-child
	//	 ArrayList<?> l6=new ArrayList<? extends Number>(); //invalid Syntax wrong
	//	 ArrayList<?> l7=new ArrayList<?>(); //invalid  synatx is incorrect
		 
		 
    //		 TypeParameter at Method level
	//       we use extends to put limit on the input data 	 
		 public <T> void methodOne1(T t){}//valid
		 public<T extends Number> void methodOne2(T t){}//valid
		 public<T extends Number&Comparable> void methodOne3(T t){}//valid
		 public<T extends Number&Comparable&Runnable> void methodOne4(T t){}//valid
	//	 public<T extends Number&Thread> void methodOne(T t){}//invalid two class can't be extends together
	//	 public<T extends Runnable&Number> void methodOne(T t){}//invalid interface can't come in front of a class
		 public<T extends Number&Runnable> void methodOne5(T t){}//valid

		 
        
        
	}

	

}
