
class Add{
	int add(int a, int b) {
		int res = a+b;
		return res;
	}
	int add (int a, int b, int c) {
		int res = a+b+c;
		return res;
	}
	float add(float a, float b) {
		return a+b;
	}
	float add (float a, int b) {
		return a+b;
	}
	float add (float a, float b, float c) {
		return a+b+c;
	}
	float add (float a, int b, float c) {
		return a+b+c;
	}
	double add(float a, int b, double c) {
		return a+b+c;
	}
	double add(double a, int b, double c) {
		return a+b+c;
	}
	double add(double a, double b, double c) {
		return a+b+c; }
	double add(double a, double b) {
		return a+b;
	}
	
}



public class LaunchCalci1{
	public static void main(String args[]) {
		int a=10, b=20, c=5;
		float x=9, y=25, z=75;
		double j=8,k=8, l=70;
		Add calci=new Add();
		System.out.println(calci.add(a, b));
		System.out.println(calci.add(x, b));
		System.out.println(calci.add(x, y, z));
		System.out.println(calci.add(j,k,l));
		System.out.println(calci.add(y,a,z));
		System.out.println(calci.add(z,c,l));
		System.out.println(calci.add(a, b));
		
	}

}