class Calculator2{
	int add(float a, int b) {
		return b + (int)a;
	}
}


public class LaunchMOSC2{
	public static void main(String args []) {
		Calculator2 calci = new Calculator2();
		System.out.println(calci.add(5, 15));
		
	}
}