

	class Demo3{
		static int x; // static varable
		static int y;
		
		static {    //this is static block
			x= 10;
			y= 20;
			System.out.println("Static block");
		}
		static void disp() {    // this is static method
			System.out.println("Static method");
			System.out.println(x);
			System.out.println(y);
		}
		
		int a; //instance varable
		int b;
		{        // non-static block
			a=10;
			b=20;
			System.out.println("Non-static java block");
		}
		Demo3(){ // constructor
			System.out.println("Constructor");
		}
		void disp1() { //non-static method
			System.out.println("Non-Static method");
			System.out.println(a);
			System.out.println(b);
		}
		
		void disp2() {
			disp1(); // we can call a method in another method of same class
		}
		
		
	}


	public class CallMethodInsideAmethod {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Demo3.disp(); //static method can be called without object creation
			Demo3 d = new Demo3();
			d.disp(); //and static method can be called after object creation also
			d.disp1();
			

		}

	}