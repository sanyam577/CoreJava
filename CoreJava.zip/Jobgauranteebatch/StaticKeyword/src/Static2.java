//static1 and static2 are same

class Demo4{
	static int x; 
	static int y;
	
	static {    
		x= 10;
		y= 20;
		System.out.println("Static block");
	}
	
	
	static void disp() {    
		System.out.println("Static method");
		System.out.println(x);
		System.out.println(y);
	}
	
	
	int a; 
	int b;
	
	
	{        
		a=10;
		b=20;
		System.out.println("Non-static java block");
	}
	
	
	Demo4(){ // constructor
		System.out.println("Constructor");
	}
	
	
	void disp1() { //non-static method
		System.out.println("Non-Static method");
		System.out.println(a);
		System.out.println(b);
		
	}
	
}


public class Static2 {

	public static void main(String[] args) {
		
		Demo4.disp(); 
		Demo4 d = new Demo4();
		d.disp(); 
		d.disp1();
		

	}

}









