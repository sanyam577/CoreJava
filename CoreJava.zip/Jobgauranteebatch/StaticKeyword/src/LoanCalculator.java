import java.util.Scanner;
class Farmer{
	private float pa; // principal amount
	private float td; //Time duration
	private float si;  //Simple interest
	private static float ra;  // Rate of interest
	
	static
	{
		ra = 2.5f;
	}
	
	void input() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter principal amount");
		pa  = scan.nextFloat();
		
		System.out.println("Kindly enter the time duration required");
		td  = scan.nextFloat();
		
	}
	
	void compute() {
		si =(pa*td*ra)/100;
	}
	void disp() {
		System.out.println("Simple interest is " + si);
		
	}
	
	
}


public class LoanCalculator {

	public static void main(String[] args) {
		
		Farmer f1 = new Farmer();
		f1.input();
		f1.compute();
		f1.disp();
		
		Farmer f2 = new Farmer();
		f2.input();
		f2.compute();
		f2.disp();

	}

}
