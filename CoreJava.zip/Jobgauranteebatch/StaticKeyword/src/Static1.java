class Demo{
	static int x; // static varable
	static int y;
	
	
	static {    //this is static block
		x= 10;
		y= 20;
		System.out.println("Static block");
	}
	
	static void disp() {    // this is static method
		System.out.println("Static method");
		System.out.println(x);
		System.out.println(y);
	}
	
	
	int a; //instance varable
	int b;
	
	
	{        // non-static block
		a=10;
		b=20;
		System.out.println("Non-static java block");
	}
	
	
	Demo(){ // constructor
		System.out.println("Constructor");
	}
	
	
	void disp1() { //non-static method
		System.out.println("Non-Static method");
		System.out.println(a);
		System.out.println(b);
	}
	
	
}


public class Static1 {

	public static void main(String[] args) {
		
		Demo.disp(); //static method can be called without object creation
		Demo d = new Demo(); // object creation or constructor call
		d.disp(); //and static method can be called after object creation also
		d.disp1();
		

	}

}
