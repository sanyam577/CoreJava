class Demo5{
	int a;
	int b;
	static int count;
	{
	count++;	
	System.out.println("Hello lion king");
	}
	
	Demo5(){
		this(100);
		System.out.println("First Constructor");
		
		
	}
	Demo5(int a){
		System.out.println(a);
		this.a=a;
	}
	Demo5(int a, int b){
		this.a =a;
		this.b = b;
	}
	
}

public class CountObject {

	public static void main(String[] args) {
		Demo5 d1 = new Demo5();
		Demo5 d2 = new Demo5(10);
		Demo5 d3 = new Demo5(10, 20);
		
		System.out.println(Demo5.count);

	}

}


