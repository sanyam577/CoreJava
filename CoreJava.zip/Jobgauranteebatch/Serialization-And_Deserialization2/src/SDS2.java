import java.io.*;
/*
class Animal {
	int i=10;
	Animal(){
		System.out.println("This is non-parametrized parent constructor");
	}
}
class Dog extends Animal implements Serializable{ //child can extend parent and implement Serializable interface
	int j=20;
	Dog(){
		System.out.println("This is non-parametrized child constructor");
	}
	
}
public class SDS2 {

	public static void main(String[] args)throws Exception {
		Dog d = new Dog();
		System.out.println("Serialization started");
		String fileName ="dog.ser";
		
		FileOutputStream f = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(f);
		oos.writeObject(d);
		System.out.println("Serialization ended");
		
		System.in.read();
		System.out.println("De-Serialization started");
		FileInputStream fi = new FileInputStream("dog.ser");
		ObjectInputStream ois = new ObjectInputStream(fi);
		Object obj = ois.readObject();
		Dog d1 = (Dog)obj;
		System.out.println(d1.i+"---->"+d1.j);
		System.out.println("De-Serialization ended");
		
		

	}

}
*/

//jvm while performing serialization will check for instance variable coming from NonSerializable parent
//for these variables jvm will give deafult value.

//At the time de-serialization, jvm will check weather any parent class is non-Serializable parentor not
//if any parent class is nonSerializable then jvm will create a separate object for every nonSerializable parent
//and shares its instance variable to the current object
//jvm make a call to non parameterized constructor 

class Animal {
	int i=10;
	Animal(){
		System.out.println("This is non-parametrized parent constructor");
	}
}
class Dog extends Animal implements Serializable{ //child can extend parent and implement Serializable interface
	int j=20;
	Dog(){
		System.out.println("This is non-parametrized child constructor");
	}
	
}
public class SDS2 {

	public static void main(String[] args)throws Exception {
		Dog d = new Dog();
		d.i = 889;  //value 
		d.j = 999;
		
		
		System.out.println("Serialization started");
		String fileName ="dog.ser";
		
		FileOutputStream f = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(f);
		oos.writeObject(d);
		System.out.println("Serialization ended");
		
		System.in.read();
		System.out.println("De-Serialization started");
		FileInputStream fi = new FileInputStream("dog.ser");
		ObjectInputStream ois = new ObjectInputStream(fi);
		Object obj = ois.readObject();
		Dog d1 = (Dog)obj;
		System.out.println(d1.i+"---->"+d1.j);
		System.out.println("De-Serialization ended");
		
		

	}

}



















