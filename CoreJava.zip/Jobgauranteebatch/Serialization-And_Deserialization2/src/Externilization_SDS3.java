import java.io.Externalizable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.*;

/*
class Demo implements  Serializable {
	String name;
	int i;
	int j;
	
	public Demo() {
		System.out.println("public zero argument constructor is called");
	}
	
	public Demo(String name, int i, int j) {
		this.name = name;
		this.i=i;
		this.j=j;
	}
	
}
public class Externilization_SDS3  {

	public static void main(String[] args)throws Exception {
		
		Demo d1 = new Demo("sachin",10,100);

		System.out.println("Serialization started");
		String fileName ="abc.ser";
		
		FileOutputStream f = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(f);
		oos.writeObject(d1);
		System.out.println("Serialization ended");
		
		System.in.read();
		
		System.out.println("De-Serialization started");
		FileInputStream fi = new FileInputStream("abc.ser");
		ObjectInputStream ois = new ObjectInputStream(fi);
		Demo d2 =(Demo)ois.readObject();
		
		System.out.println(d2.name+"====>"+d2.i+"---->"+d1.j);
		System.out.println("De-Serialization ended");
		

	}

}
*/

class Demo implements  Externalizable { //by using externalization we can control the variables to participate in serialization
	String name;
	int i;
	int j;
	
	public Demo() {
		System.out.println("public zero argument constructor is called");
	}
	
	public Demo(String name, int i, int j) {
		this.name = name;
		this.i=i;
		this.j=j;
	}
	
	//write logic for selective serialization
	public void  writeExternal(ObjectOutput oo)throws IOException{    
		System.out.println("writeExternal() is called for serializable" );
		//variables need to participate write into abc.ser
		oo.writeObject(name); //now here we controlling the variables only two out of three  are going to participate in serialization
		oo.writeInt(i);
	}
	public void  readExternal(ObjectInput oi)throws IOException, ClassNotFoundException{     
		System.out.println("readExternal() is called for serializable" );
		//variables need to retrieved from abc.se
		name =(String)oi.readObject();
		i    =oi.readInt();
		
	}
		
}
public class Externilization_SDS3  {

	public static void main(String[] args)throws Exception {
		
		Demo d1 = new Demo("sachin",10,100);

		System.out.println("Serialization started");
		String fileName ="abc.ser";
		
		FileOutputStream f = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(f);
		oos.writeObject(d1); //it will call writeExternal()
		System.out.println("Serialization ended");
		
		System.in.read();
		
		System.out.println("De-Serialization started");
		FileInputStream fi = new FileInputStream("abc.ser");
		ObjectInputStream ois = new ObjectInputStream(fi);
		Demo d2 =(Demo)ois.readObject();//it will call readExternal()
		
		System.out.println(d2.name+"====>"+d2.i);
		System.out.println("De-Serialization ended");
		

	}

}

















