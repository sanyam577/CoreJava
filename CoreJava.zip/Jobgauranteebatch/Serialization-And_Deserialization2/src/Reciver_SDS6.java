import java.io.*;

class Cat implements Serializable{
	private static final long serialVersionUID =9L;
	int i=9;
	int j=7;
}

public class Reciver_SDS6 {

	public static void main(String[] args)throws Exception {
		
		System.out.println("De-Serialization started");
		FileInputStream fi = new FileInputStream("Cat.ser");
		ObjectInputStream ois = new ObjectInputStream(fi);
		Object obj = ois.readObject();
		Cat c1 = (Cat)obj;
		System.out.println(c1.i+"---->"+c1.j);
		System.out.println("De-Serialization ended");

	}

}