import java.io.*;

class Cat implements Serializable{
	private static final long serialVersionUID =9L;
	int i=9;
	int j=7;
}

public class Sender_SDS4 {

	public static void main(String[] args) throws Exception {
		
		Cat c = new Cat();
		
		System.out.println("Serialization started");
		String fileName ="Cat.ser";
		
		FileOutputStream f = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(f);
		oos.writeObject(c);
		System.out.println("Serialization ended");

	}

}
