 import java.io.*;
 //class Object implemets Serializable{} now object class don't implement serializable interface naturally
 
 
	class Animal1 implements Serializable{
		int i=10;
	}
	class Dog1 extends Animal1{    //if parent is implementing serializable interface then child need not to implement 
		int j=20;                                   //serializable interface
	}	

	public class Inheritance_In_SDS1 {

		public static void main(String[] args)throws Exception {
			
			Dog1 d = new Dog1();
			System.out.println("Serialization started");
			String fileName = "abcd.ser";
			FileOutputStream fos = new FileOutputStream(fileName);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(d); //this method 

	        System.out.println("Serialization ended");
	        
	        System.in.read(); //this will make us wait on console until we don't press enter
	        
	        System.out.println("De-Serialization started");
			FileInputStream fis = new FileInputStream("abcd.ser");
			ObjectInputStream ois = new ObjectInputStream(fis);
			Object obj =ois.readObject();
			Dog1 d1 =(Dog1)obj;
			
			System.out.println(d1.i+"------->"+d1.j);
	        System.out.println("De-Serialization ended");
			
		}

	}
	
	