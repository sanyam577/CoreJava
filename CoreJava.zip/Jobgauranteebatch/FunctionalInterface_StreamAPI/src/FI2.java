//Example of method reference
@FunctionalInterface
interface Interf2{
	public void m1(int i);
}
public class FI2 {
	public void m2(int i) {
		System.out.println(i*i);
		System.out.println("logic coming from method reference.....");
	}
	public static void main(String[] args) {
		Interf2 i = x-> System.out.println(x);
		i.m1(10);
		
		System.out.println();
		
		//method reference (binding the body of m2() to abstract method m1())
		Interf2 i1 = new FI2()::m2; //if method is static then we need to use new
		i1.m1(20);

	}

}
