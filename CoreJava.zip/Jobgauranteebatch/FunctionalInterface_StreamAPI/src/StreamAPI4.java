import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
//count() method
public class StreamAPI4 {

	public static void main(String[] args) {
			
				ArrayList<String> names = new ArrayList<String>();
				names.add("ramji");
				names.add("sitaji");
				names.add("laxmanji");
				names.add("hanumanji");
				System.out.println(names);
	
	long count = names.stream().filter(name->name.length()>5).count(); 
  			System.out.println("The number of object whoes string length is greater than 5: "+ count);
  	
  			//we can also use this		
  	List<String> result=names.stream().filter(name->name.length()>5).collect(Collectors.toList()); //this method is lengthy		
  	System.out.println("The number of object whoes string length is greater than 5: "+ result.size());
  			
	}

}
