import java.util.ArrayList;

//.min() and .max() 
public class StreamAPI6 {

	public static void main(String[] args) {
		
		ArrayList<Integer> al = new ArrayList<Integer>();
        al.add(10);
        al.add(0);
        al.add(15);
        al.add(5);
        al.add(20);
      System.out.println("Before sorting : "+al);
   
      Integer min = al.stream().min((i1,i2)->i1.compareTo(i2)).get();
      System.out.println(min);
      
      Integer max = al.stream().max((i1,i2)->i1.compareTo(i2)).get();
      System.out.println(max);
      

	}

}
