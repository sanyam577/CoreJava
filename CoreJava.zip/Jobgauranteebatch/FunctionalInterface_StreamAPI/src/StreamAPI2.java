import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

//.map() function 
/*
public class StreamAPI2 {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(0);
		al.add(5);
		al.add(10);
		al.add(15);
		al.add(20);
		al.add(25);
		
		System.out.println(al);
		
		//till jdk1.7V
		ArrayList<Integer> doubleList = new ArrayList<Integer>();
		for(Integer i1: al)
		doubleList.add(i1*2);
		
		System.out.println(doubleList);
		
		//from jdk1.8v
		//map-> for every object, if a new object has to be created then go for Map
		List<Integer> streamList=al.stream().map(obj->obj*2).collect(Collectors.toList());
		System.out.println(streamList);
		streamList.forEach(i->System.out.println(i));
		streamList.forEach(System.out::println);
		
	}

}
*/

//.map() function 
public class StreamAPI2 {

	public static void main(String[] args) {
		TreeSet<Integer> al = new TreeSet<Integer>();
		al.add(0);
		al.add(5);
		al.add(10);
		al.add(15);
		al.add(20);
		al.add(25);
		
		System.out.println(al);
		
		//till jdk1.7V
		TreeSet<Integer> doubleList = new TreeSet<Integer>();
		for(Integer i1: al)
		doubleList.add(i1*2);
		
		System.out.println(doubleList);
		
		//from jdk1.8v
		//map-> for every object, if a new object has to be created then go for Map
		List<Integer> streamList=al.stream().map(obj->obj*2).collect(Collectors.toList());
		System.out.println(streamList);
		streamList.forEach(i->System.out.println(i));
		streamList.forEach(System.out::println);
		
	}

}















