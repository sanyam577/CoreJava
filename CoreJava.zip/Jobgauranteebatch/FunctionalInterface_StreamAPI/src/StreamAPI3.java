import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamAPI3 {

	public static void main(String[] args) {
		
		ArrayList<String> names = new ArrayList<String>();
		names.add("ramji");
		names.add("sitaji");
		names.add("laxmanji");
		names.add("hanumanji");
		System.out.println(names);
		
		
		//till jdk1.7v
		ArrayList<String> upperCase = new ArrayList<String>();
		for(String name: names) {
			upperCase.add(name.toUpperCase()); //First names will go name then it will covert into upper case then it will
			                                      //be added in upperCase ArrayList
		}
		System.out.println(upperCase);
		
		System.out.println("************************************************");
		//from jdk1.8v
	    List<String> streamList =names.stream().map(name->name.toUpperCase()).collect(Collectors.toList());
	    System.out.println("************************************************");
		System.out.println(streamList);
		System.out.println("************************************************");
		streamList.forEach(i-> System.out.println(i));
		System.out.println("************************************************");
		streamList.forEach(System.out::println);
		
		

	}

}
