//The Consumer Interface is a part of the java.util.function package which has been introduced since Java 8.
//It represents a function which takes in one argument and produces a result. However these kind of functions don’t return any value.
//Hence this functional interface which takes in one generic namely:- 
// T: denotes the type of the input argument to the operation
//Functions in Consumer Interface :- 1. accept() This method accepts one value and performs the operation on the given argument
import java.util.*;
import java.util.function.*;

/*
//public void forEach(java.util.function.Consumer<? super E>);
public class FI3 {

	public static void main(String[] args) {
		
		ArrayList<String> names = new ArrayList<String>();
		names.add("sachin");
		names.add("dhoni");
		names.add("kholi");
		names.add("david");
		
		names.forEach(System.out :: println);

	}

}
*/

class MyConsumer implements Consumer<String>{
	@Override
	public void accept(String name) {
		System.out.println("accept method got called...");
		System.out.println(name);
	}
}
public class FI3 {

	public static void main(String[] args) {
		
		ArrayList<String> names = new ArrayList<String>();
		names.add("sachin");
		names.add("dhoni");
		names.add("kholi");
		names.add("david");
		
		//Traditional approach
		Consumer<String> consumer = new MyConsumer();
		names.forEach(consumer);
		
		System.out.println();
		
		//lambda expression
		names.forEach(name->System.out.println(name));
		System.out.println();
		
		//method reference
		names.forEach(System.out :: println);

	}

}

























