//Constructor Reference is used to refer to a constructor without instantiating the named class.
//In the constructor reference expressions, instead of specifying the exact constructor, we just write "new". However, 
//a class may have multiple constructors. In that case, compiler checks the type of the target functional interface with 
//each of the constructors in the class, and finally chooses the best match.
// in Constructor Reference java uses interface’s function and refers to correct constructor that matches the signature.
//Finally, as these are only references to the methods or constructors, the methods or constructors are not invoked lazily.

class Sample
{
  private String s;
  Sample(String s){
	  this.s = s;
	  System.out.println("Constructor executed... "+s);
  }
}
@FunctionalInterface
interface Interf{
	public Sample get(String s);
} 


public class FI1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Interf i = (s)-> new Sample(s); // when we are creating object in lambda expression then we can replace it with
		System.out.println();               // constructor reference
		i.get("From lambda expression");
		
		Interf i1 = Sample::new;     // constructor reference   object::methodName
		i.get("From lambda expression");
		i1.get("From construction refrence...");

	}

}
