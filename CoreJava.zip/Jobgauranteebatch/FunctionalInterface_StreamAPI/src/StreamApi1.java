//the Stream API is used to process collections of objects. 
//A stream is a sequence of objects that supports various methods which can be pipelined to produce the desired result.
//.filter() method 
 
import java.util.*;
import java.util.stream.*;

public class StreamApi1 {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<Integer>();
          al.add(0);
          al.add(5);
          al.add(10);
          al.add(15);
          al.add(20);
          al.add(25);
          
          System.out.println(al); //[0, 5, 10, 15, 20, 25]
          
         // till jdk1.7v
          ArrayList<Integer> evenList = new ArrayList<Integer>();
          for(Integer i1: al)
        	 if(i1%2==0)
        	  evenList.add(i1);
          System.out.println(evenList); //[0, 10, 20]
          
       //From jdk1.8v we start using Streams
          //total 3 process 
          //1.Configuration
          //2.Processing
          //3.Collection
          
          //gives the implementation class object of Stream(I)    java.util.stream.ReferencePipeline$Head@54bedef2
         // Stream str = al.stream(); //configration done
         
          List<Integer> streamList = al.stream().filter(i->i%2==0).collect(Collectors.toList());
          System.out.println(streamList);
          streamList.forEach(System.out :: println);
          
          //in this program we are doing filtering
           
	}

}
