import java.util.ArrayList;

//now we are going to convert Collection into Array with the help of .toArray() method

public class StreanAPI7 {

	public static void main(String[] args) {
		
		ArrayList<Integer> al = new ArrayList<Integer>();
        al.add(10);
        al.add(0);
        al.add(15);
        al.add(5);
        al.add(20);
      System.out.println("Before sorting it's a collection : "+al);
      
      System.out.println("after sorting it's an object array ");
       Object [] objArr = al.stream().toArray();
        for(Object ar: objArr)
        	System.out.println(ar);
        
        System.out.println("after sorting it's an Integer array ");
        Integer [] intArr = al.stream().toArray(Integer[]::new);
        for(Object arr: intArr)
        	System.out.println(arr);
        
        
        
        
        
	}

}
