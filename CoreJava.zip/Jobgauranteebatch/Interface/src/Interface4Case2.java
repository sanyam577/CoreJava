//A interface can extends for more than one interface
interface IDemo11{
	void m1();
}
interface IDemo22{
	void m2();
}
interface IDemo33 extends IDemo11, IDemo22{ //an interface can extends for more than one interface
	void m3();
}

class SampleImpl2 implements IDemo33{ //a class can implements interface
	
	public void m1() {}
	public void m2() {}
	public void m3() {}
	
	
}

public class Interface4Case2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
