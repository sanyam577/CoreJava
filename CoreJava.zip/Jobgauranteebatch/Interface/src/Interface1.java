interface ISample{
	//interface class must be a 100% abstract class
	//method of interface class is "public and abstract"
	void m1();
	void m2(); // these two are abstract method
}

class SampleImpl implements ISample{ //as we were using extends in inheritance, here we use implements keyword 
	
	@Override //indication to compiler that these methods are overridden methods
	public void m1() {
		System.out.println("hey implementation given for method m1");
	}
	
	@Override
	public void m2() {
		System.out.println("hey implementation given for method m2");
	}
}


public class Interface1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ISample sample = new SampleImpl(); //loose coupling
		sample.m1();
		sample.m2();

	}

}
