// if 2 interfaces contain a method with same signature and same return type in the implementation class only one method implementation is enough
interface ISamples{
	void m1();
}
interface IDemos{
	void m1();
}
class CommonImpl implements ISamples, IDemos
{
	public void m1() {} // both interfaces with same method name is vaild
}


public class Interface6 {
	public static void main(String [] args) {
		
	}

}
/*
 * 
 * // if 2 interfaces contain a method with same name but having different arguments  in the
 *  implementation class we have to provide implementation for both methods and these methods will act like overloaded methods
  interface ISamples{
	void m1();
}
interface IDemos{
	void m1(int i);
}
class CommonImpl implements ISamples, IDemos
{
    @Override
	public void m1() {} 
	
	@Override               //method override is valid
	public void m1(int i) {} 
}


public class Interface6 {
	public static void main(String [] args) {
		
	}

}
*/





/*
interface ISamples{
	void m1();
}
interface IDemos{
	int m1();
}
class CommonImpl implements ISamples, IDemos
{
	@Override
	public void m1() {} //same method signature or name (m1)
	
	@Override             //error because of different return type 
	public int m1()
}


public class Interface6 {
	public static void main(String [] args) {
		
	}


*/















