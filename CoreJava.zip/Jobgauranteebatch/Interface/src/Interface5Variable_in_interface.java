/*interface IRemote{
	
	//SRS
	public static  final int MIN_VOL =0; //variable must be final so that no one change it's value, it must be public so that we can access it from any part of the program, 
	                                     //and static so that we can call it by it's class name
	public static final int MAX_VOL=100; 
	// we can avoid writing public static final infront of varaiable because by default variable in interface is public static final 
	//int MIN_VOL =0;
	//int MAX_VOL=100;

}

class LGImpl implements IRemote
{
	System.out.println(IRemote.MIN_VOL);
	System.out.println(IRemote.MAX_VOL);
}
*/




/*
interface ISample {
	int a= 10;
}

 class Interface5Variable_in_interfaceImpl implements ISample {

	public static void main(String[] args) {
		a=20; // we can not reassigned value to a final variable (variable present in interface is final public and static)
		System.out.println(a);

	}

}*/
 
 interface ISamplee {
		int a= 10;
	}

	 class Interface5Variable_in_interfaceImpl implements ISamplee {

		public static void main(String[] args) {
			int a=20; // yes it is possible if we assign value to the same variable at run time (here int a is a local variable)
			System.out.println(a);

		}

	}
 
 
 
 
 
 
 
 
 
 
 
