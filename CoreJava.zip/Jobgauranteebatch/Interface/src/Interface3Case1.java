//a class can extends for only one class and can implements for one or more than one interface
class Sample {
	public void m01() {
		
	}
}
interface IDemo {
	void m02();
}
interface IDemoo {
	void m03();
}

class DemoImpl extends Sample implements IDemo, IDemoo //first extends for class then implements for interface (interfaces can be more than one)
{
	public void m02() {}
	public void m03() {}
}


public class Interface3Case1 {
	public static void main(String [] args) {
		
	}

}
