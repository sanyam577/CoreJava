interface ISample1{
	void m11();
	void m22();
}
//if you override both the methods in one class then you need not to write abstract keyword in front of SampleImpl class (example- interface1)
//but if you override only one class in SampleImpl class then you have to write abstract keyword and also have to make another normal class (child class)

abstract class Sample1Impl implements ISample1{
	
	@Override
	public void m11() {
		System.out.println("hey implementation given for method m11");
	}
	// one concrete method and one abstract method (hidden which is coming from ISample1 :- void m22()) 
}

//now for the second method we have to create another class
 class SubSample1Impl extends Sample1Impl{
	 @Override
		public void m22() {
			System.out.println("hey extends given for method m22");
	 }
	 
 }

public class Interface2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ISample1 obj = new SubSample1Impl();
		obj.m11();
		obj.m22();

	}

}
