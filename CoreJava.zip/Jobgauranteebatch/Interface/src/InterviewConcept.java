//Can abstract class be instantiated/ object be created ? ans. NO
//Can abstract class contains constructor? ans. Yes 
//Can interface object be instantiated ? ans. NO
//Can interface conatains constructor? ans. No instance variables, so
                                        // so constructor not required.

abstract class Person {
	String name ;
	Integer age;
	Float height;
	
	// To initialize the instance variables
	Person(String name, Integer age, Float height){
		this.name = name;
		this.age =age;
		this.height =height;
	}
}

class Students extends Person {
	Integer sid;
	Float marks;
	String courseName;
	
	Students(String name, Integer age, Float height,
			Integer sid, Float marks, String courseName){
		super(name,age,height);
		 
		 this.sid= sid;
		 this.marks = marks;
		 this.courseName =courseName;
	}
	
	void disp() {
		 System.out.println(name);
		 System.out.println(age);
		 System.out.println(height);
		 System.out.println(sid);
		 System.out.println(marks);
		 System.out.println(courseName);
	}
	
	
}

public class InterviewConcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Students s1 = new Students("Ram", 52 , 25.6f, 7777, 107f, "Lok Kalyan");
                  s1.disp();
	}

}
