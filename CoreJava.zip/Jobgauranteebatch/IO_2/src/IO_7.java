import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;

//Alternate lines from two files paste in third file
public class IO_7 {

	public static void main(String[] args)throws Exception {
		
        PrintWriter pw = new PrintWriter("new3.txt"); //third file where copied data will go
		
		BufferedReader br1 = new BufferedReader(new FileReader("abc.txt")); // first file
		String line1 = br1.readLine();
		BufferedReader br2 = new BufferedReader(new FileReader("abc1.txt"));
			String line2 = br2.readLine();
		
		while(line1!=null || line2!=null) {
			
			if(line1!=null) {
			pw.println(line1); // line by line data from abc.txt will go to new.txt file
			line1 = br1.readLine();
			}
			if(line2!=null) {
			pw.println(line2); // line by line data from abc.txt will go to new.txt file
			line2 = br2.readLine();
			}
		}
			
			pw.flush(); //because of writing
			
			br1.close();
			br2.close();
			pw.close();
			
			System.out.println("for output go to IO_2 ");

	}

}
