import java.io.*;
//bufferedWriter write the things line by line

public class IO_2 {

	public static void main(String[] args)throws Exception {
		FileWriter fw = new FileWriter("abc.txt");
	//	FileWriter fw = new FileWriter("abc.txt" , true); //to append
		BufferedWriter bw = new BufferedWriter(fw);
		
		bw.write(105);
		bw.newLine();
		bw.write("Neuron"); //to add content
		
		bw.newLine();
		char[] ch = {'P', 'W', 'S', 'K', 'I', 'L', 'L', 'S'};
		bw.write(ch);
		
		bw.newLine(); //for line gap
		
		bw.write("Unicorn of the year");
		
		bw.flush(); //to make sure the operation is succesfull on file
		
		bw.close(); //internally fw.close() call will happen

	}

}
