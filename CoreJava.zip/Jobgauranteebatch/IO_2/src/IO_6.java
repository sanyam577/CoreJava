import java.io.*;
//here we are copying line one from abc.txt and line one from abc1.txt and pasting it to file new2.txt
public class IO_6 {

	public static void main(String[] args)throws Exception {
		
PrintWriter pw = new PrintWriter("new2.txt"); //third file where copied data will go
		
		BufferedReader br = new BufferedReader(new FileReader("abc.txt")); // first file
		String line = br.readLine();
		pw.println(line);
		
		
		//for second file
		 br = new BufferedReader(new FileReader("abc1.txt")); //second file
			line = br.readLine();
			pw.println(line);
			
			
			pw.flush(); //because of writing
			
			br.close();
			pw.close();
		
		
		

	}

}
