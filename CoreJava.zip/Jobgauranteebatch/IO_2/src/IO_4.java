//printWriter we use when we have to write any type of data
//out.write() is used to write for the first time 
//out.write('\n') it used to change line for the first time
//out.println() is used to write data and it will change line automatically  

import java.io.*;

public class IO_4 {

	public static void main(String[] args)throws Exception {
		FileWriter fw = new FileWriter("abc1.txt");
		PrintWriter out = new PrintWriter(fw);
		 
		out.write(100); //100 unicode value will be written to a file
		out.write('\n');
		 
		out.println(100); //100 will be written to a file
		out.println(true);
		out.println('y');
		out.println("Ram");
		
		out.flush();
		out.close();

	}

}
