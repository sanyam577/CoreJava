//here we are going to copy data present in two files and paste in another third file
import java.io.*;

public class IO_5 {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		
		PrintWriter pw = new PrintWriter("new.txt"); //third file where copied data will go
		
		BufferedReader br = new BufferedReader(new FileReader("abc.txt")); // first file
		String line = br.readLine();
		
		while(line!=null) {
			pw.println(line); // line by line data from abc.txt will go to new.txt file
			line = br.readLine();
		}
		
		//for second file
		 br = new BufferedReader(new FileReader("abc1.txt"));
			line = br.readLine();
			
			while(line!=null) {
				pw.println(line); // line by line data from abc.txt will go to new.txt file
				line = br.readLine();
			}
			
			pw.flush(); //because of writing
			
			br.close();
			pw.close();
			
	}

}
