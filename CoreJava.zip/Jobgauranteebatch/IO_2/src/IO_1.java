import java.io.File;
import java.io.FileReader;

//public int read(char[]) method 
//here read one character and then store it char array then again read one character 
//and store it char array   
//after storing use the at once char array so performance is high
public class IO_1 {

	public static void main(String[] args)throws Exception {
		File f = new File("Student.txt");
		FileReader f1 = new FileReader(f);
		
		char[] ch = new char[(int)f.length()];
		f1.read(ch); //read and store the data in char array so performance is high
		
		for(char data:ch)
			System.out.println(data);
		
		f1.close();
		
	}

}
