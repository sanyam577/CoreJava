import java.io.*;
//here we are trying to not print duplicate value in target file
public class IO_8 {

	public static void main(String[] args)throws Exception {
		
		PrintWriter pw = new PrintWriter("output.txt"); //target file where copied data will go
		
		BufferedReader br = new BufferedReader(new FileReader("mobile.txt")); // first file
		
		String target = br.readLine();
		while(target!=null) {
			
			boolean flag =false;
			
			BufferedReader br1 = new BufferedReader(new FileReader("output.txt"));
			String line =br1.readLine();
			
			//control comes out of while loop in smooth fashion without break
			while(line!=null) {
				//if matched control should come out
				if(line.equals(target)) {
					flag = true;
					break;
				}
				line = br1.readLine();
			}
			
		   if(flag==false)
			   pw.println(target);
		       pw.flush();
		       
		       
		   target = br.readLine(); 
		  
		}
		br.close();
		
		pw.close();
		
			
			

	}

}
