import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;

public class IO_9 {
//it will check unique data present in file 1 and file 2 and then print  it to third file
	public static void main(String[] args)throws Exception {
PrintWriter pw = new PrintWriter("output1.txt"); //target file where copied data will go (third file)
		
		BufferedReader br = new BufferedReader(new FileReader("input1.txt")); // first file
		
		String target = br.readLine();
		while(target!=null) {
			
			boolean flag =false;
			
			BufferedReader br1 = new BufferedReader(new FileReader("delete1.txt")); //second file
			String line =br1.readLine();
			
			//control comes out of while loop in smooth fashion without break
			while(line!=null) {
				//if matched control should come out
				if(line.equals(target)) {
					flag = true;
					break;
				}
				line = br1.readLine();
			}
			
		   if(flag==false)
			   pw.println(target);
		       pw.flush();
		       
		       
		   target = br.readLine(); 
		  
		}
		br.close();
		
		pw.close();
		
		
	}
}
