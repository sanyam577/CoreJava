//return types of child method and parent method can be different if it is co-variant return type means it shows (is-A relationship)  
// here Interest and InterestPersonalLoan class are in (is-A type relationship) means Interest is parent of InterestPersonalLoan class 
class Interest // first class
{
	
}
class InterestPersonalLoan extends Interest //second class 
{
	
}


class Loans
{
	public Interest interest() //return type is Interest 
	{
		Interest it=new Interest();
		return it;
	}
}

class PersonalLoan1 extends Loans
{
	public InterestPersonalLoan interest() // return type is InterestPersonalLoan 
	{                                       // as we can see return type of method in class is diffrent
		                                     //from parent method (interest) but it is valid
		
		InterestPersonalLoan ipl=new InterestPersonalLoan();
		return ipl;
	}
}



public class LaunchLoans {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}