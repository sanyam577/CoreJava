class Plane{
	public void takeOff() //inherited method
	{
		System.out.println("Plane is taking off");
	}	
	public void fly() 
	{
		System.out.println("Plane is flying");
	}
	public void land() //inherited method
	{
		System.out.println("Plane is landing");
	}	
}



class CargoPlane extends Plane{
	public void fly() //overridden method (because it is already present in parent class and here we are modifying it)
	{
		System.out.println("CargoPlane flys at lower height");
	}
	public void carryGoods() //Specialized method (newly introduced not present in parent class)
	{
		System.out.println("CargoPlane carries goods");
	}
	
}

class PassengerPlane extends Plane{
	public void fly()  //overridden method
	{
		System.out.println("PassangerPlane flys at minimum height");
	}
	public void carryPassanger() //Specialized method
	{
		System.out.println("It carries passangers");
	}
	
}


public class InheritedOverridenSpecialised_methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CargoPlane cp = new CargoPlane();
		cp.takeOff();
		cp.fly();
		cp.land();
		cp.carryGoods();
		
		PassengerPlane pp = new PassengerPlane();
		pp.takeOff();
		pp.fly();
		pp.land();
		pp.carryPassanger();

	}

}
