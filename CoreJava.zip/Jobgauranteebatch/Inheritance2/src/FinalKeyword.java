final class Vehicle{ //final keyword in front of class
	
	void disp() {
		System.out.println("Vehicle");
	}
}
class Car extends Vehicle{ // final class can not be inherited that,s why it's showing error
	
}






public class FinalKeyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car cc = new Car();
		cc.disp();

	}

}
