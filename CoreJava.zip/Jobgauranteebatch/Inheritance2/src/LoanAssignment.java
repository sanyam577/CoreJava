import java.util.Scanner;

abstract class Loan1{ //abstraction
	abstract public void personalDetails();
	
	public double PrinAmount;
	public double rate =5.2;
	public double time;
	public double Si;
	
	public void intrest()
	{
		System.out.println("Enter Amount");
		Scanner scan = new Scanner(System.in);
		PrinAmount = scan.nextDouble();
		System.out.println("Enter Time duration");
		time = scan.nextDouble();
		Si = (PrinAmount*rate*time)/100;
		System.out.println("simple intrest is " + Si);
		
	}		
}


class PersoonalLoan extends Loan1 {//inheritance
	
	public String name ;
	public int age ;
	public String gender;
	
	public void personalDetails() {
		System.out.println("Enter your name");
		Scanner scan = new Scanner(System.in);
		name = scan.nextLine();
		System.out.println("Enter your age");
		age = scan.nextInt();
		System.out.println("Enter your gender");
		gender = scan.next();
		System.out.println();
		
	}
	public double rate = 12.12;
	
	public void intrest()
	{
		System.out.println("Enter Amount");
		Scanner scan = new Scanner(System.in);
		PrinAmount = scan.nextDouble();
		System.out.println("Enter Time duration");
		time = scan.nextDouble();
		Si = (PrinAmount*rate*time)/100;
		System.out.println("simple intrest is " + Si);
		
	}	
}


class EducationLoan extends Loan1{
	public String name ;
	public int age ;
	public String gender;
	
	public void personalDetails() {
		System.out.println("Enter your name");
		Scanner scan = new Scanner(System.in);
		name = scan.nextLine();
		System.out.println("Enter your age");
		age = scan.nextInt();
		System.out.println("Enter your gender");
		gender = scan.next();
		System.out.println();
		
	}	
public double rate = 6.0;
	
	public void intrest()
	{
		System.out.println("Enter Amount");
		Scanner scan = new Scanner(System.in);
		PrinAmount = scan.nextDouble();
		System.out.println("Enter Time duration");
		time = scan.nextDouble();
		Si = (PrinAmount*rate*time)/100;
		System.out.println("simple intrest is " + Si);
		
	}	
}



class HomeLoan extends Loan1{
	
	public String name ;
	public int age ;
	public String gender;
	
	public void personalDetails() {
		System.out.println("Enter your name");
		Scanner scan = new Scanner(System.in);
		name = scan.nextLine();
		System.out.println("Enter your age");
		age = scan.nextInt();
		System.out.println("Enter your gender");
		gender = scan.next();
		System.out.println();
		
	}	
    public double rate = 10.0;
	
	public void intrest()
	{
		System.out.println("Enter Amount");
		Scanner scan = new Scanner(System.in);
		PrinAmount = scan.nextDouble();
		System.out.println("Enter Time duration");
		time = scan.nextDouble();
		Si = (PrinAmount*rate*time)/100;
		System.out.println("simple intrest is " + Si);
		
	}	
	
}


class CarLoan extends Loan1{
	public String name ;
	public int age ;
	public String gender;
	
	public void personalDetails() {
		System.out.println("Enter your name");
		Scanner scan = new Scanner(System.in);
		name = scan.nextLine();
		System.out.println("Enter your age");
		age = scan.nextInt();
		System.out.println("Enter your gender");
		gender = scan.next();
		System.out.println();
		
	}	
    public double rate = 9.0;
	
	public void intrest()
	{
		System.out.println("Enter Amount");
		Scanner scan = new Scanner(System.in);
		PrinAmount = scan.nextDouble();
		System.out.println("Enter Time duration");
		time = scan.nextDouble();
		Si = (PrinAmount*rate*time)/100;
		System.out.println("simple intrest is " + Si);
		
	}	
	
}

class Valid {
	public void permit(Loan1 loan) { //polymorphism
		loan.personalDetails();
		loan.intrest();
		
	}
}


public class LoanAssignment {

	public static void main(String[] args) {
		
		PersoonalLoan p1 = new PersoonalLoan();
		EducationLoan e1 = new EducationLoan();
		HomeLoan h1 = new HomeLoan();
		CarLoan c1 = new CarLoan();
		
		
		Valid v = new Valid();
		v.permit(p1);
		v.permit(e1);
		v.permit(h1);
		v.permit(c1);
		

	}

}
