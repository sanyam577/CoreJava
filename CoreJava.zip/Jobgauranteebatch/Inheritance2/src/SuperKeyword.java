class Demo11 {
	int age = 28;
}
class Demo22 extends Demo11 {
	int age =26;
	void disp() {
		System.out.println(super.age); // We use super keyword to take variable  data from parent class it does't
		                                   //matter if it is present in child class or not not
	}
}




public class SuperKeyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo22 sup = new Demo22();
		sup.disp(); // we are calling dips() method from Demo22 class but the value of age we are getting is 28
		             //(because of super keyword)

	}

}
