//we can't override static method 
class Parent4{
	public static void disp() {
		System.out.println("Hello parent");
	}
}
class Child4 extends Parent4{
	
	
	public static void disp() { // we are trying to override static method here but because of static keyword
		                     //this method is considered as specialized method (this is known as method hiding)
		System.out.println("Hello Child4");
	}
}


public class MethodHidingUsingStstic {

	public static void main(String[] args) {
		Parent4 p = new Child4();
		p.disp(); // output will Hello Parent means disp() method is not overriden

	}

}
