class Vehicle1{
	    final int i = 10; // final keyword in front of variable
	 void disp() { 
		  i = 20;  // Error because final variable act like a constant value we can not change it
		 System.out.println(i);
		System.out.println("Vehicle");
	}
}
class Car1 extends Vehicle1 { 
	
}

public class FinalKeyword_on_variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}













