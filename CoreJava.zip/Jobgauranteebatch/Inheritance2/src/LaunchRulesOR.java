class Demo1{
	void disp(){
		System.out.println("Demo1 is parent");
	}	
	public void disp2() {
		
	}
	public int add() {
		return 10+20;
	}
	public int add(int a, int b) {
		return a+b;
	}
	
}
 class Demo2 extends Demo1{
	 public void disp() { // we can increase visibility (in child class method it is default but here it is public)
		 
	 }
	 void disp2(){ //we can not reduce visibility of child class method
		 
	 } 
	 public void add() { // we can not change return data type of child class method
		 
	 }
	 public void add(int a, int b)
		{
			return a+b;
	}
	 
	 public int add(int a)
		{
			return a;
		}
	 
	 
 }
 
 public class LaunchRulesOR {

		public static void main(String[] args) {
			// TODO Auto-generated method stub

		}

	}
