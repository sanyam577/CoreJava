//from java 8.0 we can add method having body in interface but condition is that you have to use default keyword
//we can override that method or we can directly access it without overriding
//here default is not access modifier its just a keyword

//from java 8.0 we can add method having body in interface but condition is that you have to use static keyword
//we can't override that method means it's not going to participate in inheritance
//you can directly access it with class name
//here default is not access modifier its just a keyword

//from java 9.0 we can have private keyword before a method in interface
//we can not access it anywhere except in the same class method

interface Hab {
	void rob();
	default void show() {
		System.out.println("Interface method can have body");
		reuse();
	}
	static void disp() {
			System.out.println("We can use static keyword");
	}
	private void reuse() {
		System.out.println("we can use it within interface");
	}
	
}
class Bibi implements Hab{
	public void rob() {
		System.out.println("You are a rabbit");
	}
//	public void show() {
//		System.out.println("We can override it ");
//	}
	
}


public class Java8AndJava9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Bibi b = new Bibi();
       b.rob();
       b.show();
       
       Hab.disp();
	}

}
