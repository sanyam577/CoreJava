class Loan
{
	void disp()
	{
		System.out.println("Welcome to INEURON BANK");
	}
}
class PersonalLoan extends Loan
{
	void disp() // return type of child method (overridden) must be same as parent method .
	                    //Here we can see both are void
	{
		System.out.println("Personal loan app");
	}
}



public class LaunchLoan 
{
	public static void main(String[] args)
	{
		PersonalLoan pl=new PersonalLoan();
		pl.disp();
	}
}


