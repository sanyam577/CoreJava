class Vehicle1{
	
	final void disp() { // final keyword in front of method
		System.out.println("Vehicle");
	}
}
class Car1 extends Vehicle1 { // no error means we can inherit final method 
	
}

public class FinalKeyword_in_method {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car1 cc = new Car1();
		cc.disp();
	}

}
