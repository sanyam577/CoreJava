class Vehicle1{
	
	final void disp() { // final keyword in front of method
		System.out.println("Vehicle");
	}
}
class Car1 extends Vehicle1 { // means we can inherit final method 
	void disp() { // but can not override final method 
		System.out.println("Vehicle"); 
	}
}

public class FinalKeyword_in_method2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car1 cc = new Car1();
		cc.disp();
	}

}