// finally will dominant the return keyword
/*
class Demo{

	int demo() {
	
			System.out.println("method started");
			return 10;
	    //  System.out.println("method started");   code after return statement will not execute 
		
	}
}


public class Finally_Exception_handling3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Demo d = new Demo();
         d.demo();
	}

}
*/

// but because of finally block it will execute




/*
class Demo{
	int demo() {
		try {
			System.out.println("method started");
			return 10;
		}
		finally{
			System.out.println("method closed");
		}
	}
}


public class Finally_return_Exception_handling3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Demo d = new Demo();
         d.demo();
	}

}

*/






// but System.exit(0) will dominate finally block and end the program at the same line 
// no further execution of program after Sysem.exit(0);

class Demo{
	void demo() {
		try {
			System.out.println("method started");
			System.exit(0);;
		}
		finally{
			System.out.println("method closed");
		}
	}
}


public class Finally_return_Exception_handling3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Demo d = new Demo();
         d.demo();
	}

}



