//in this case exception is first handled by alpha then by main 
//This is known as re-throwing
import java.util.Scanner;

class Alpha1{ 
	  
	  void alpha() throws ArithmeticException //it will throw the exception towards the caller method which is main 
	  {                                  // this is known as Ducking (indication to caller that this method have exception )
		
		System.out.println("Calculator.com");
	    try {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a number"); 
		int x = scan.nextInt();
		System.out.println("Enter a number as divisor"); 
		int y = scan.nextInt();
		
		int res = x/y;
		
		System.out.println("here is the result "+ res);
	    }
	    catch(ArithmeticException ae) {
	    	System.out.println("Exception handled in alpha");
	    	throw ae;             //it is used to show exception that will pass to caller even it is handled by alpha ,
	    }                        //main will again handle it (ex: atm blocking) this process is known as re-throwing
	                            // line below the throw  is not executing so that we have to use finally block
	    finally {
		System.out.println("connection is terminated");
	    }
    }
  }


public class Exception_handling2_throwBoth
{

	public static void main(String[] args)  
	{
		try {
	    System.out.println("Connected to main");
		Alpha1 a = new Alpha1();
		a.alpha();
		}
		catch(ArithmeticException ae){ 
			System.out.println(ae.getMessage()); // print the description of the exception
			//System.out.println(ae.toString()); //   print the name and description of the exception
			//ae.printStackTrace(); // print the description of the exception along with the stack trace 
			System.out.println("Exception handled in main");
		}
		
	}

}
