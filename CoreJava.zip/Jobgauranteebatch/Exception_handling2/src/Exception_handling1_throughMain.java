import java.util.Scanner;
  class Alpha{ 
	  
	  void alpha() throws ArithmeticException //it will throw the exception towards the caller method which is beta
	  {
		
		System.out.println("Calculator.com");
	
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a number"); 
		int x = scan.nextInt();
		System.out.println("Enter a number as divisor"); 
		int y = scan.nextInt();
		
		int res = x/y;
		
		System.out.println("here is the result"+ res);
		System.out.println("connection is terminated");
    }
  }
  
  class Beta{
	  void beta() throws ArithmeticException //it will throw the exception towards the caller method which is main method
	  {
	  Alpha a = new Alpha();
	  a.alpha();
	  }
  }
		
		
		public class Exception_handling1_throughMain {

			public static void main(String[] args) {
				try {
					Beta b = new Beta();
					b.beta();
				}
				catch(ArithmeticException e) {
					System.out.println("finally exception is resolved"); //finally exception will be handled in main 
					                                                    //method by using try and catch block
				}

	}

}
