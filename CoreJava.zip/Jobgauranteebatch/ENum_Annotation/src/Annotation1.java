//If we have to convey a message to another programmer then we use annotation
//Or we can say it's additional information to our source code
//it may be inbuilt or user define
//Every annotation has it's own target Ex: @FunctionalInterface we use it for interface only
//Every annotation has it's own Retention policy , means it's reach maybe upto compiler , jvm or maybe as a comment
//It works on the basis of interface

//@CricketPlayer
//class virat
//{ }

// Annotation --> can be used with :-
 //1) class
//2) interface
//3) method
// 4) fields // instance var 
//5 ) local variables
// 6) Consrtuctor 
// 7) Parameters
// 8) enum 

@FunctionalInterface
interface Trail {
  int getNum();
  //void disp();
}

class JavaLearning{
	public void disp1() {
		System.out.println("Java Learning class");
	}
}

class Focus extends  JavaLearning{
	@Override //let suppose if we forgot to write 1 in disp1 method then complier will show error because of annotation(Override)
	public void disp1() {
		System.out.println("Focus is the key");
	}
}

public class Annotation1 {

	public static void main(String[] args) {
		
		Trail t= ()->
		{
			return 10;
		};

	}

}
