//with the help of eNum we can create our own data type
//Variables in eNum are written in Capital letter 
//we can write eNum inside a class or outside of a class
//Variables in eNum are public static and final
//As like class and interface eNum can have variables , method and constructor
//When we create a variable in eNum behind the scene a object is created for it
//Like class and interface for eNum also there will be a .class file will be generated
//Ex:- NORTH SOUTH EAST WEST
//     MALE FEMALE OTHERS
//     FAIL PASS NR (no result)

enum Result1
{
	PASS, FAIL, NR;
	
}
enum Gender{
	MALE, FEMALE, OTHERS;
}
enum Compas{
	NORTH, SOUTH, EAST, WEST;
}

public class ENum1 {
	
	enum Week{ //eNum can be inside a class also
         SUN, MON, TUS, WED, THR, FRI, SAT; 
	}

	public static void main(String[] args) {
		

	}

}
