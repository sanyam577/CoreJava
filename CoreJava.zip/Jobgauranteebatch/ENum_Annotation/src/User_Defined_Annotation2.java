import java.lang.annotation.Target;
import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/*
//If we put @ symbol in front of interface then it will turned into Annotation

@interface CricketPlayer{
    	
}

class ViratKholi{
	private int innings;
	private String name;
	
	public int getInnings() {
		return innings;
	}
	public void setInnings(int innings) {
		this.innings = innings;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
		
}
public class User_Defined_Annotation2 {

	public static void main(String[] args) {
		
		ViratKholi vk = new ViratKholi();
		vk.setInnings(3000);
		vk.setName("VK");
		
		System.out.println(vk.getInnings());
		System.out.println(vk.getName());
		
	}

}
*/

/*
//now we are going to define variables in annotation
//There are two ways to assign values to variables present inside annotation block
//1. by using default    2. assign value where you are using it 
//We only pass data to annotation if it is demanding

@interface CricketPlayer{
    //	String country() default "India"; //1
   // 	int runs() default 2000;
	
	  String country();
	  int runs();
}


@CricketPlayer(country="India", runs = 2000) //2
class ViratKholi{
	private int innings;
	private String name;
	
	public int getInnings() {
		return innings;
	}
	public void setInnings(int innings) {
		this.innings = innings;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
		
}
public class User_Defined_Annotation2 {

	public static void main(String[] args) {
		
		ViratKholi vk = new ViratKholi();
		vk.setInnings(3000);
		vk.setName("VK");
		
		System.out.println(vk.getInnings());
		System.out.println(vk.getName());
		
	}

}
*/


//For whom we are going to use this annotation we need to define it as Target (for class, method, variable, interface)
//What is the limitation of this annotation is determined by it Retention Policy (as a comment, upto complier, upto jvm, upto web browser)

/*
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@interface CricketPlayer{
    //	String country() default "India"; //1
   // 	int runs() default 2000;
	
	  String country();
	  int runs();
}


@CricketPlayer(country="India", runs = 2000) //2
class ViratKholi{
	private int innings;
	private String name;
	
	public int getInnings() {
		return innings;
	}
	public void setInnings(int innings) {
		this.innings = innings;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
		
}
public class User_Defined_Annotation2 {

	public static void main(String[] args) {
		
		ViratKholi vk = new ViratKholi();
		vk.setInnings(3000);
		vk.setName("VK");
		
		System.out.println(vk.getInnings());
		System.out.println(vk.getName());
		
	}

}
*/




//now we are going to access values inside annotation block


@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@interface CricketPlayer{
    	String country() default "India"; //1
    	int runs() default 2000;
	
	 // String country();
	 // int runs();
}


//@CricketPlayer(country="India", runs = 2000) //2
@CricketPlayer
class ViratKholi{
	private int innings;
	private String name;
	
	public int getInnings() {
		return innings;
	}
	public void setInnings(int innings) {
		this.innings = innings;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
		
}
public class User_Defined_Annotation2 {

	public static void main(String[] args) {
		
		ViratKholi vk = new ViratKholi();
		vk.setInnings(3000);
		vk.setName("VK");
		
		System.out.println(vk.getInnings());
		System.out.println(vk.getName());
		
		//to access values inside annotation block we are going to use reflection API
		//we are going to use the inbuilt methods
		
		Class c =vk.getClass(); //to get the class where we are using annotation we are using .getClass() method
	    Annotation an =	c.getAnnotation(CricketPlayer.class); //now we are access the annotation block
	    CricketPlayer cp = (CricketPlayer) an; //type casting because annotation is of parent type we can't use it directly
	    
	    //now we can access data with the help of cp
	    int run =cp.runs();
	    System.out.println(run);
	    
	    String cn =cp.country();
	    System.out.println(cn);
	}

}

//one annotation block can have multiple target means we can use it for method, class, variable , filed , interface..
//@Target({ElementType.TYPE ,ElementType.METHOD , ElementType.LOCAL_VARIABLE })

















