//behind every variable of eNum there a object
import java.util.*;
enum Result{
	PASS, FAIL, NR; //Static final
	//PASS--> public static final Result PASS = new Result(); Obj1
	//FAIL--> public static final Result FAIL = new Result(); Obj2
	//NR--> public static final Result NR = new Result();     Obj3
	
	Result(){ //this is constructor of eNum and here we can't write public in front of it because it is called by internally
	   System.out.println("Constructor is called by these three object");	                                     //generated object
		
	}
	
	
	}
public class ENum2 {

	public static void main(String[] args) {
		
		Result res = Result.PASS;
		System.out.println(res);
		
	     Result [] resArr=Result.FAIL.values();
	     
	     for(Result Y025:resArr) {
	    	 System.out.println(Y025.ordinal()+" "+ Y025.name());
	     }
		
		

	}

}
