class Fan{
	int price;
	String brandName;
	int Mfg;
}



public class FanClass {
	public static void main(String args []) {
	Fan[] arr=new Fan[3];
	arr[0]= new Fan();
	arr[1]= new Fan();
	
	arr[0].price = 1000;
	arr[0].brandName = "Mohini";
	arr[0].Mfg = 26/05/2022;
	
	System.out.println(arr[0].brandName);
	System.out.println(arr[0].price);
	
		
	}

}
