import java.util.Scanner;

public class MarksOfStudents {
	public static void main(String args []) {
	int[] ar = new int[6];
    Scanner	scan= new Scanner(System.in);
    
    for(int i=0; i<ar.length; i++) {
    	System.out.println("Enter the marks" +i);
    	ar[i]=scan.nextInt();
    }
	System.out.println("Marks are as follows");
	
   
	for(int i=0; i<ar.length; i++) {

    	System.out.print(ar[i]+" ");
    }
	}

}
