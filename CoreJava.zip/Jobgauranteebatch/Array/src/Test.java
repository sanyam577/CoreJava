
public class Test {
	public static void main(String args []) {
		int [][] a = {{25,26,78},{5,8,9}};
		for(int i=0; i<a.length;i++) {
			for(int j=0; j<a[i].length; j++) {
		System.out.print(a[i][j]+" ");}
			System.out.println();
		}
	
	}
      

}
