import java.util.Scanner;

public class Array3D {
	public static void main(String args []) {
	Scanner	scan= new Scanner(System.in);
	int [][][] arr=new int[2][3][4];
	
	for(int i=0; i<arr.length;i++) {
		for(int j=0; j<arr[i].length;j++) {
			for(int k=0; k<arr[i][j].length;k++) {
				System.out.println("Enter the marks of school "+i+" Class "+j+" Marks "+k);
				arr[i][j][k]=scan.nextInt();
				
			}
		}
	}
	System.out.println("Marks are as follows:-");
	for(int i=0; i<arr.length;i++) {
		for(int j=0; j<arr[i].length;j++) {
			for(int k=0; k<arr[i][j].length;k++) {
				System.out.print(arr[i][j][k]+ " ");
				
			}
			System.out.println();
		}
	}
	

	}

}
