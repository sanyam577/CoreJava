import java.util.Arrays;
/*
public class Array2DJUsingForEach {

	public static void main(String[] args) {
		int [][] a = {{2,2},{5 ,6 ,9},{8,7,7,3}};
		for(int ar[]: a) {
			for(int elem: ar) {
				System.out.print(elem +" ");
			}
			System.out.println();
		}

	}

}
*/
/*
  //For 3D using for each
public class Array2DJUsingForEach {

	public static void main(String[] args) {
		int [][][] a = {{{2,5,8},{6,8,4,7},{2,2}},  {{5,8,7},{6,9,7,7}}};
		for(int ar[][]: a) {
			for(int elem[]: ar) {
				for(int three: elem) {
				System.out.print(three +" ");
				}
				System.out.println();
			}
			System.out.println();
		}

	}

}
*/

//Array in different way
public class Array2DJUsingForEach {

	public static void main(String[] args) {
		int [] ab, cd;
		ab = new int[4];
		cd = new int[2];
		
		ab[0] = 5;
		ab[1] = 2;
		ab[2] = 3;
		ab[3] = 4;
		 
		cd[0] = 3;
		cd[1] = 2;
		
		Arrays.sort(ab);
		Arrays.sort(cd);
		
		//Arrays.fill(ab,9);
		for(int res: ab) {
			System.out.print(res +" ");
		}
		System.out.println();
		
		for(int ar: cd) {
			System.out.print(ar +" ");		}
		
	}

}









