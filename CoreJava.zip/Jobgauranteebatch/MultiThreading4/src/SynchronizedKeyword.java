import java.sql.*;
//in this program you will see output random , total 3 threads main, t1 and t2
//when we call wish method two threads will start running parallel that will result in unordered output
//to avoid this we introduced synchronized keyword, if one thread started execution other thread have to wait until 
//first one is not done execution
//Synchronized is an object level lock means it will put a lock on object
//if method is static and synchronized then the lock will be at class level


//Case 1. Only one user defined thread t1
/*
class Display{
	public void wish(String name) {
		for(int i=0; i<=5; i++) {
			System.out.print("Good Evening: ");
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				
			}
			System.out.println(name);
		}
	}
	
}

class MyThread extends Thread{
	
	Display d;
	String name;
	
	MyThread(Display d, String name){
		this.d = d;
		this.name = name;
	}
	
	
	@Override
	public void run() {
		d.wish(name);
	}
}


public class SynchronizedKeyword {

	public static void main(String[] args) {
		Display d= new Display();
		
		MyThread t1 = new MyThread(d,"Sachin");
		t1.start();

	}

}
*/

//Case2. Two user defined threads t1 and t2 , unordered output
/*
class Display{
	public void wish(String name) {
		for(int i=0; i<=5; i++) {
			System.out.print("Good Evening: ");
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				
			}
			System.out.println(name);
		}
	}
	
}

class MyThread extends Thread{
	
	Display d;
	String name;
	
	MyThread(Display d, String name){
		this.d = d;
		this.name = name;
	}
	
	
	@Override
	public void run() {
		d.wish(name);
	}
}

public class SynchronizedKeyword {

	public static void main(String[] args) {
		Display d= new Display();
		
		MyThread t1 = new MyThread(d,"Sachin");
		t1.start();
		
		MyThread t2 = new MyThread(d, "Dhoni");
		t2.start();

	}

}

*/
/*
// Synchronized keyword 
class Display{
	public synchronized void wish(String name) {
		for(int i=0; i<=5; i++) {
			System.out.print("Good Evening: ");
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				
			}
			System.out.println(name);
		}
	}
	
}

class MyThread extends Thread{
	
	Display d;
	String name;
	
	MyThread(Display d, String name){
		this.d = d;
		this.name = name;
	}
	
	
	@Override
	public void run() {
		d.wish(name);
	}
}

public class SynchronizedKeyword {

	public static void main(String[] args) {
		Display d= new Display();
		
		MyThread t1 = new MyThread(d,"Sachin");
		t1.start();
		
		MyThread t2 = new MyThread(d, "Dhoni");
		t2.start();

	}

}
*/


//MultiThreading by creating two objects
//who knows which thread will get a chance 
/*
class Display{
	public void wish(String name) {
		for(int i=0; i<=5; i++) {
			System.out.print("Good Evening: ");
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				
			}
			System.out.println(name);
		}
	}
	
}

class MyThread extends Thread{
	
	Display d;
	String name;
	
	MyThread(Display d, String name){
		this.d = d;
		this.name = name;
	}
	
	
	@Override
	public void run() {
		d.wish(name);
	}
}

public class SynchronizedKeyword {

	public static void main(String[] args) {
		Display d1= new Display();
		Display d2= new Display();
		
		MyThread t1 = new MyThread(d1,"Sachin");
		t1.start();
		
		MyThread t2 = new MyThread(d2, "Dhoni");
		t2.start();

	}

}
*/

// No effect on output even after using synchronized keyword
class Display{
	public synchronized void wish(String name) {
		for(int i=0; i<=5; i++) {
			System.out.print("Good Evening: ");
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				
			}
			System.out.println(name);
		}
	}
	
}

class MyThread extends Thread{
	
	Display d;
	String name;
	
	MyThread(Display d, String name){
		this.d = d;
		this.name = name;
	}
	
	
	@Override
	public void run() {
		d.wish(name);
	}
}

public class SynchronizedKeyword {

	public static void main(String[] args) {
		Display d1= new Display();
		Display d2= new Display();
		
		MyThread t1 = new MyThread(d1,"Sachin");
		t1.start();
		
		MyThread t2 = new MyThread(d2, "Dhoni");
		t2.start();

	}

}

