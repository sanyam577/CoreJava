/*
class Display1{
	public synchronized void displayNumbers() {
		for(int i=0; i<=10; i++) {
			System.out.print(i);
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
			
			}
		}
	}
	
	public synchronized void displayCharacters() {
		for(int i=65; i<=75; i++) {
			System.out.print((char)i);
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e){
				
			}
			
	    }
	}
}
class MyThread1 extends Thread{
	
	Display1 d;
	MyThread1(Display1 d){
		this.d = d;
		
	}
	@Override
	public void run() {
		d.displayNumbers();
	}
}
class MyThread2 extends Thread{
	
	Display1 d;
	MyThread2(Display1 d){
		this.d = d;
		
	}
	@Override
	public void run() {
		d.displayCharacters();
	}
}




public class Synchronized2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display1 d1= new Display1();
		
		
		MyThread1 t1 = new MyThread1(d1);
		t1.start();
		
		MyThread2 t2 = new MyThread2(d1);
		t2.start();
		
		

	}

}*/
//Output:: 012345678910ABCDEFGHIJK  means they are using object lock that's one thread start execution after the first
//one ended it's execution



//now let's remove synchronized keyword from method
/*
class Display1{
	public synchronized void displayNumbers() {
		for(int i=0; i<=10; i++) {
			System.out.print(i);
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
			
			}
		}
	}
	
	public void displayCharacters() {
		for(int i=65; i<=75; i++) {
			System.out.print((char)i);
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e){
				
			}
			
	    }
	}
}
class MyThread1 extends Thread{
	
	Display1 d;
	MyThread1(Display1 d){
		this.d = d;
		
	}
	@Override
	public void run() {
		d.displayNumbers();
	}
}
class MyThread2 extends Thread{
	
	Display1 d;
	MyThread2(Display1 d){
		this.d = d;
		
	}
	@Override
	public void run() {
		d.displayCharacters();
	}
}

public class Synchronized2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display1 d1= new Display1();
		
		
		MyThread1 t1 = new MyThread1(d1);
		t1.start();
		
		MyThread2 t2 = new MyThread2(d1);
		t2.start();
		
		

	}

}
*/
//Output:: 0AB12CD34EF56GH7I89JK10 it will be in unordered manner one method which is without synchronized keyword will
//enter in between the first thread even though it is using object level lock



// now let's remove synchronized keyword from both methods
class Display1{
	public void displayNumbers() {
		for(int i=0; i<=10; i++) {
			System.out.print(i);
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
			
			}
		}
	}
	
	public void displayCharacters() {
		for(int i=65; i<=75; i++) {
			System.out.print((char)i);
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e){
				
			}
			
	    }
	}
}
class MyThread1 extends Thread{
	
	Display1 d;
	MyThread1(Display1 d){
		this.d = d;
		
	}
	@Override
	public void run() {
		d.displayNumbers();
	}
}
class MyThread2 extends Thread{
	
	Display1 d;
	MyThread2(Display1 d){
		this.d = d;
		
	}
	@Override
	public void run() {
		d.displayCharacters();
	}
}

public class Synchronized2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display1 d1= new Display1();
		
		
		MyThread1 t1 = new MyThread1(d1);
		t1.start();
		
		MyThread2 t2 = new MyThread2(d1);
		t2.start();
		
		

	}

}
//Output:: 0AB1C23DE45FG6H78I9JK10 very much similar to previous one  




