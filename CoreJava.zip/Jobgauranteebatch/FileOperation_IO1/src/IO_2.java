import java.io.*;
//creating directory
//java.io.api classes are built using the standards of Unix OS.
//In Linux/Unix OS there is no difference b/w file and directory
public class IO_2 {

	public static void main(String[] args) throws Exception
	{
		String directoryName = "IPLteam";
		// f.exists()  :- this line will check weather the directory called "IPLteam" exists or not
		//if it is not available then it would go and point to that directory
		File f = new File(directoryName); //java file object
		System.out.println(f.exists()); //false   

		//it will create a physical directory for the java File object
		f.mkdir();
		System.out.println();
		System.out.println(f.exists()); //true
	}
//jvm shutdown now
}

