import java.io.*;

public class IO_4 {

	public static void main(String[] args) throws Exception
	{
		
		String location = "c:\\pwskills";
		File f = new File(location);
		f.mkdir(); //new folder or directory
		
		File f1 = new File(f, "java.txt"); //new file "java.txt" in pwskills folder will be generated
		f1.createNewFile();
		
		/*
		public long length(); //no of characters present in file
		public boolean delete(); //it deletes file or directory based on file Object
		public String[] list(); //it returns the name of all files and directories under specified directory 
       */		

	}

}
