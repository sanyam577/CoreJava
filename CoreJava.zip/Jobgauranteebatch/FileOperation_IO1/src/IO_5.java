import java.io.*;

//write a program to display the names of all files and directories present in C:\Users\singh\Downloads
/*
public class IO_5 {

	public static void main(String[] args) {
		int dirCount = 0;
		int fileCount = 0;
		
		String location = "C:\\Users\\singh\\Downloads";
		File f = new File(location);
		
		String[] names = f.list();
		
		for(String name: names) {
			//creating a file object for f->(directory)
			//using f->(fileName)
			File f1 = new File(f, name);
			
			if(f1.isDirectory())
				dirCount++;
			if(f1.isFile())
				fileCount++;
			System.out.println(name);
		}
		System.out.println("Total no of files is :: "+fileCount);
		System.out.println("Total no of directories is :: "+dirCount);
		
	}

}
*/

//to count .img and .txt file

public class IO_5 {

	public static void main(String[] args) {
		int dirCount = 0;
		int jpgFileCount = 0;
		int txtFileCount = 0;
		int zipFileCount = 0;
		int pngFileCount = 0;
		
		String location = "C:\\Users\\singh\\Downloads";
		File f = new File(location);
		
		String[] names = f.list();
		
		for(String name: names) {
			//creating a file object for f->(directory)
			//using f->(fileName)
			File f1 = new File(f, name);
			
			if(f1.isDirectory())
				dirCount++;
			if(name.endsWith(".jpg"))
				jpgFileCount++;
			if(name.endsWith(".txt"))
				txtFileCount++;
			if(name.endsWith(".zip"))
				zipFileCount++;
			if(name.endsWith(".png"))
				pngFileCount++;
			
			System.out.println(name);
		}
		System.out.println("Total no of jpg files is :: "+jpgFileCount);
		System.out.println("Total no of txt files is :: "+txtFileCount);
		System.out.println("Total no of zip files is :: "+zipFileCount);
		System.out.println("Total no of png files is :: "+pngFileCount);
		System.out.println("Total no of directories is :: "+dirCount);
		
	}

}























