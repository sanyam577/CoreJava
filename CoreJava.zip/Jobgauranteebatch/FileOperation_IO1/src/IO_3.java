import java.io.File;

public class IO_3 {

	public static void main(String[] args) throws Exception
	{
		File f = new File("iNeuron"); 
        f.mkdir(); //it will create new directory in current working directory
        System.out.println("Is f pointing to a directory :: "+f.isDirectory());
        
        File f1 = new File(f, "abc.txt");
        f1.createNewFile(); //it will create new file in current working directory
        System.out.println("Is f pointing to a file :: "+f1.isFile());
        
	}

}
