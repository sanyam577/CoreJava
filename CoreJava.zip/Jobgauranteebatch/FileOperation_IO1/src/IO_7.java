import java.io.File;
import java.io.FileReader;
//for FileReader there must be a file present in the directory so first of all create new file and then use FileReader
// we are going to use this method
//public int read()  here read one character and then use it then again read one character 
//and use it  
public class IO_7 {

	public static void main(String[] args)throws Exception {
		String location = "c:\\PWskills";
		File f = new File(location);
		
		File f1 = new File(f, "Player.txt"); 
		f1.createNewFile();
		
		FileReader f2 = new FileReader("c:\\PWskills\\Player.txt");
		int i = f2.read();
		
		while(i!=-1) {
			System.out.print((char)i+"====>");
			i=f2.read();
			System.out.println(i);
		}
		

	}

}
