import java.io.File;
//creating file
public class IO_1 {

	public static void main(String[] args) throws Exception
	{
		String fileName = "abc.txt";
		//this line will check weather the file called "abc.text" exists or not
		//if it is not available then it would go and point to that file
		//Otherwise it will represent a java file object, not a physical file
		File f = new File(fileName); //java file object
		System.out.println(f.exists()); //false

		//it will create a physical file for the java file object
		f.createNewFile();
		System.out.println(f.exists()); //true
	}
//jvm shutdown now
}
