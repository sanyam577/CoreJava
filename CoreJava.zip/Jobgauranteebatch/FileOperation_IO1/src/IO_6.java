import java.io.File;
import java.io.FileWriter;


/*
public class IO_6 {

	public static void main(String[] args)throws Exception {
		
		String location = "c:\\PWskills";
		File f = new File(location);
		f.mkdir(); //new folder or directory
		
		File f1 = new File(f, "abc.txt"); 
		
		//FileWriter will create file if it is not present
		//If it is present it will point that file , pointing can be done in two ways 1. append 2. override
		FileWriter f2 = new FileWriter(f1);
		//performing write operation on a file
		f2.write(97);
		f2.write("\n");
		f2.write("Boy name Robin");
		f2.write("\n");
		char [] ch = {'F','r','o','m',' ','H','e','l','l'};
		f2.write(ch);
		
		//closing the resource 
		f2.close();
		
		System.out.println("open abc.txt to see the output");
		//if we run the file second time then it will override the content
		
	}

}
*/

//now we are going to avoid overriding 
//and going to append new things

public class IO_6 {

	public static void main(String[] args)throws Exception {
		
		String location = "c:\\PWskills";
		File f = new File(location);
		f.mkdir(); //new folder or directory 
		
		File f1 = new File(f, "abc.txt"); 
		
		
		FileWriter f2 = new FileWriter(f1, true); //append
	//	FileWriter f2 = new FileWriter(f1, false); //overriding
		//performing write operation on a file
		f2.write("\n");
		f2.write(97);
		f2.write("\n");
		f2.write("Boy name Robin");
		f2.write("\n"); //sometimes \n not works then we need to use ASCII value of \n at his place
		char [] ch = {'F','r','o','m',' ','H','e','l','l'};
		f2.write(ch);
		
		//making the data to write to the file
		f2.flush();
		
		//closing the resource 
		f2.close();
		
		System.out.println("open abc.txt to see the output");
		//if we run the file second time then it will override the content
		
		

	}

}











